import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Layout } from '@/components/layout/Layout';
import { ProviderRegistrationForm } from '@/components/provider/ProviderRegistrationForm';
import { BloodStockGrid } from '@/components/provider/BloodStockGrid';
import { BloodCampForm } from '@/components/provider/BloodCampForm';
import { BloodCampList } from '@/components/provider/BloodCampList';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Building2, Clock, CheckCircle, XCircle, AlertCircle, Phone, Mail, MapPin, Droplet, Calendar } from 'lucide-react';

export default function ProviderDashboard() {
  const { user, role, organization, loading } = useAuth();
  const navigate = useNavigate();
  const [campRefreshTrigger, setCampRefreshTrigger] = useState(0);

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
    if (!loading && role && role !== 'provider') {
      navigate('/');
    }
  }, [user, role, loading, navigate]);

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </Layout>
    );
  }

  // Show registration form if no organization
  if (!organization) {
    return (
      <Layout>
        <ProviderRegistrationForm />
      </Layout>
    );
  }

  const getStatusBadge = () => {
    switch (organization.verification_status) {
      case 'approved':
        return (
          <Badge className="bg-success text-success-foreground">
            <CheckCircle className="h-3 w-3 mr-1" /> Verified
          </Badge>
        );
      case 'rejected':
        return (
          <Badge variant="destructive">
            <XCircle className="h-3 w-3 mr-1" /> Rejected
          </Badge>
        );
      default:
        return (
          <Badge variant="secondary" className="bg-warning/20 text-warning">
            <Clock className="h-3 w-3 mr-1" /> Pending Verification
          </Badge>
        );
    }
  };

  const isNgoOrBloodBank = organization.organization_type === 'ngo' || organization.organization_type === 'blood_bank';

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <h1 className="text-3xl font-bold">{organization.name}</h1>
              <p className="text-muted-foreground mt-1">Provider Dashboard</p>
            </div>
            {getStatusBadge()}
          </div>
        </div>

        {/* Pending/Rejected Notice */}
        {organization.verification_status === 'pending' && (
          <Card className="mb-6 border-warning bg-warning/5">
            <CardContent className="py-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="h-5 w-5 text-warning mt-0.5" />
                <div>
                  <h4 className="font-medium">Verification Pending</h4>
                  <p className="text-sm text-muted-foreground">
                    Your organization is under review. You'll be able to manage blood stock once approved.
                    This typically takes 1-2 business days.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {organization.verification_status === 'rejected' && (
          <Card className="mb-6 border-destructive bg-destructive/5">
            <CardContent className="py-4">
              <div className="flex items-start gap-3">
                <XCircle className="h-5 w-5 text-destructive mt-0.5" />
                <div>
                  <h4 className="font-medium">Verification Rejected</h4>
                  <p className="text-sm text-muted-foreground">
                    {organization.verification_notes || 'Your application was not approved. Please contact support for more information.'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Organization Info Card */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Organization Details
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Type</p>
                <p className="font-medium capitalize">{organization.organization_type.replace('_', ' ')}</p>
              </div>
              <div className="space-y-1 flex items-start gap-2">
                <Phone className="h-4 w-4 text-muted-foreground mt-1" />
                <div>
                  <p className="text-sm text-muted-foreground">Phone</p>
                  <p className="font-medium">+91 {organization.phone}</p>
                </div>
              </div>
              <div className="space-y-1 flex items-start gap-2">
                <Mail className="h-4 w-4 text-muted-foreground mt-1" />
                <div>
                  <p className="text-sm text-muted-foreground">Email</p>
                  <p className="font-medium">{organization.email}</p>
                </div>
              </div>
              <div className="space-y-1 flex items-start gap-2 md:col-span-2 lg:col-span-3">
                <MapPin className="h-4 w-4 text-muted-foreground mt-1" />
                <div>
                  <p className="text-sm text-muted-foreground">Address</p>
                  <p className="font-medium">{organization.full_address}</p>
                  <p className="text-sm text-muted-foreground">
                    {organization.city}, {organization.district}, {organization.state} - {organization.pincode}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Main Dashboard Content - Only for approved providers */}
        {organization.verification_status === 'approved' && (
          <Tabs defaultValue="stock" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2 lg:w-auto lg:inline-flex">
              <TabsTrigger value="stock" className="flex items-center gap-2">
                <Droplet className="h-4 w-4" />
                Blood Stock
              </TabsTrigger>
              {isNgoOrBloodBank && (
                <TabsTrigger value="camps" className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  Donation Camps
                </TabsTrigger>
              )}
            </TabsList>

            <TabsContent value="stock">
              <BloodStockGrid organizationId={organization.id} />
            </TabsContent>

            {isNgoOrBloodBank && (
              <TabsContent value="camps" className="space-y-6">
                <BloodCampForm 
                  organizationId={organization.id} 
                  onCampCreated={() => setCampRefreshTrigger(t => t + 1)} 
                />
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Calendar className="h-5 w-5" />
                      Your Scheduled Camps
                    </CardTitle>
                    <CardDescription>
                      Blood seekers in the camp location will receive email notifications 2 days before each camp
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <BloodCampList 
                      organizationId={organization.id} 
                      refreshTrigger={campRefreshTrigger} 
                    />
                  </CardContent>
                </Card>
              </TabsContent>
            )}
          </Tabs>
        )}
      </div>
    </Layout>
  );
}
