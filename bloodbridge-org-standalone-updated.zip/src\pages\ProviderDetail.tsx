import { useEffect, useState, lazy, Suspense } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Layout } from '@/components/layout/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { OrganizationWithStock, BLOOD_GROUPS } from '@/types';
import { 
  Building2, MapPin, Phone, Mail, ArrowLeft, Droplet, 
  Clock, CheckCircle, ExternalLink, Loader2 
} from 'lucide-react';

// Lazy load the map component to avoid SSR issues
const ProviderMapComponent = lazy(() => import('@/components/provider/ProviderMap'));

export default function ProviderDetail() {
  const { id } = useParams<{ id: string }>();
  const [organization, setOrganization] = useState<OrganizationWithStock | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      fetchOrganization();
    }
  }, [id]);

  const fetchOrganization = async () => {
    try {
      const { data, error } = await supabase
        .from('organizations')
        .select(`
          *,
          blood_stock (*)
        `)
        .eq('id', id)
        .single();

      if (error) throw error;

      setOrganization({
        ...data,
        blood_stock: data.blood_stock || [],
      } as OrganizationWithStock);
    } catch (error) {
      console.error('Error fetching organization:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStockInfo = (bloodGroup: string) => {
    const stock = organization?.blood_stock.find((s) => s.blood_group === bloodGroup);
    const quantity = stock?.quantity || 0;
    
    if (quantity === 0) {
      return { quantity, status: 'Unavailable', color: 'bg-destructive/10 text-destructive border-destructive/30' };
    }
    if (quantity <= 5) {
      return { quantity, status: 'Low', color: 'bg-warning/10 text-warning border-warning/30' };
    }
    return { quantity, status: 'Available', color: 'bg-success/10 text-success border-success/30' };
  };

  const getOrgTypeLabel = (type: string) => {
    switch (type) {
      case 'hospital': return 'Hospital';
      case 'blood_bank': return 'Blood Bank';
      case 'ngo': return 'NGO';
      default: return 'Organization';
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </Layout>
    );
  }

  if (!organization) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8 text-center">
          <h2 className="text-2xl font-bold mb-4">Provider Not Found</h2>
          <p className="text-muted-foreground mb-4">The provider you're looking for doesn't exist or has been removed.</p>
          <Link to="/search">
            <Button>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Search
            </Button>
          </Link>
        </div>
      </Layout>
    );
  }

  const hasCoordinates = organization.latitude && organization.longitude;

  return (
    <Layout>
      <div className="container mx-auto px-3 sm:px-4 py-4 sm:py-8">
        {/* Back Button */}
        <Link to="/search" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-4 sm:mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Search Results
        </Link>

        {/* Header */}
        <div className="flex flex-col gap-4 mb-6 sm:mb-8">
          <div className="flex items-start gap-3 sm:gap-4">
            <div className="p-2 sm:p-3 bg-primary/10 rounded-lg shrink-0">
              <Building2 className="h-6 w-6 sm:h-8 sm:w-8 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-start gap-2 flex-wrap">
                <h1 className="text-xl sm:text-2xl md:text-3xl font-bold leading-tight">{organization.name}</h1>
                <Badge variant="outline" className="text-xs shrink-0">{getOrgTypeLabel(organization.organization_type)}</Badge>
                {organization.is_demo_provider && (
                  <Badge className="bg-primary/20 text-primary text-xs shrink-0">Demo</Badge>
                )}
              </div>
              <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground">
                <CheckCircle className="h-4 w-4 text-success shrink-0" />
                <span>Verified Provider</span>
              </div>
            </div>
          </div>

          <a href={`tel:+91${organization.phone}`} className="w-full sm:w-auto">
            <Button size="lg" className="w-full sm:w-auto">
              <Phone className="mr-2 h-4 w-4 sm:h-5 sm:w-5" />
              Call Now
            </Button>
          </a>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
          {/* Blood Stock */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader className="px-4 sm:px-6 py-4 sm:py-6">
                <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                  <Droplet className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
                  Blood Availability
                </CardTitle>
              </CardHeader>
              <CardContent className="px-4 sm:px-6">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-4">
                  {BLOOD_GROUPS.map((bloodGroup) => {
                    const info = getStockInfo(bloodGroup);
                    return (
                      <div
                        key={bloodGroup}
                        className={`p-3 sm:p-4 rounded-lg border-2 text-center ${info.color}`}
                      >
                        <div className="text-lg sm:text-2xl font-bold mb-0.5 sm:mb-1">{bloodGroup}</div>
                        <div className="text-sm sm:text-lg font-semibold">{info.quantity} units</div>
                        <div className="text-[10px] sm:text-xs mt-0.5 sm:mt-1">{info.status}</div>
                      </div>
                    );
                  })}
                </div>
                <div className="mt-3 sm:mt-4 flex items-start gap-2 text-xs sm:text-sm text-muted-foreground">
                  <Clock className="h-3 w-3 sm:h-4 sm:w-4 mt-0.5 shrink-0" />
                  <span>Stock information may change. Please call to confirm availability.</span>
                </div>
              </CardContent>
            </Card>

            {/* Map */}
            {hasCoordinates && (
              <Card className="mt-4 sm:mt-6">
                <CardHeader className="px-4 sm:px-6 py-4 sm:py-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <MapPin className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
                    Location
                  </CardTitle>
                </CardHeader>
                <CardContent className="px-4 sm:px-6">
                  <div className="h-[200px] sm:h-[300px] rounded-lg overflow-hidden bg-muted">
                    <Suspense fallback={
                      <div className="h-full flex items-center justify-center">
                        <Loader2 className="h-6 w-6 sm:h-8 sm:w-8 animate-spin text-primary" />
                      </div>
                    }>
                      <ProviderMapComponent
                        latitude={Number(organization.latitude)}
                        longitude={Number(organization.longitude)}
                        name={organization.name}
                        address={organization.full_address}
                      />
                    </Suspense>
                  </div>
                  <a
                    href={`https://www.google.com/maps/dir/?api=1&destination=${organization.latitude},${organization.longitude}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-3 sm:mt-4 inline-flex"
                  >
                    <Button variant="outline" size="sm" className="text-xs sm:text-sm">
                      <ExternalLink className="mr-2 h-3 w-3 sm:h-4 sm:w-4" />
                      Get Directions
                    </Button>
                  </a>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Contact Info */}
          <div>
            <Card>
              <CardHeader className="px-4 sm:px-6 py-4 sm:py-6">
                <CardTitle className="text-base sm:text-lg">Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 sm:space-y-4 px-4 sm:px-6">
                <div className="flex items-start gap-2 sm:gap-3">
                  <Phone className="h-4 w-4 sm:h-5 sm:w-5 text-muted-foreground mt-0.5 shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs sm:text-sm text-muted-foreground">Phone</p>
                    <a href={`tel:+91${organization.phone}`} className="text-sm sm:text-base font-medium hover:text-primary break-all">
                      +91 {organization.phone}
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-2 sm:gap-3">
                  <Mail className="h-4 w-4 sm:h-5 sm:w-5 text-muted-foreground mt-0.5 shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs sm:text-sm text-muted-foreground">Email</p>
                    <a href={`mailto:${organization.email}`} className="text-sm sm:text-base font-medium hover:text-primary break-all">
                      {organization.email}
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-2 sm:gap-3">
                  <MapPin className="h-4 w-4 sm:h-5 sm:w-5 text-muted-foreground mt-0.5 shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs sm:text-sm text-muted-foreground">Address</p>
                    <p className="text-sm sm:text-base font-medium">{organization.full_address}</p>
                    <p className="text-xs sm:text-sm text-muted-foreground mt-1">
                      {organization.area && `${organization.area}, `}
                      {organization.city}, {organization.district}
                      <br />
                      {organization.state} - {organization.pincode}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Emergency Call Card */}
            <Card className="mt-4 sm:mt-6 border-primary bg-primary/5">
              <CardContent className="py-4 sm:py-6 text-center px-4 sm:px-6">
                <Droplet className="h-8 w-8 sm:h-10 sm:w-10 text-primary mx-auto mb-2 sm:mb-3" />
                <h3 className="font-semibold text-sm sm:text-base mb-1 sm:mb-2">Need Blood Urgently?</h3>
                <p className="text-xs sm:text-sm text-muted-foreground mb-3 sm:mb-4">
                  Call now to check availability and arrange collection
                </p>
                <a href={`tel:+91${organization.phone}`} className="block">
                  <Button size="lg" className="w-full text-sm sm:text-base">
                    <Phone className="mr-2 h-4 w-4 sm:h-5 sm:w-5" />
                    Emergency Call
                  </Button>
                </a>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
