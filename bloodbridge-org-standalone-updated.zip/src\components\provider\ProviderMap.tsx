interface ProviderMapProps {
  latitude: number;
  longitude: number;
  name: string;
  address: string;
}

export default function ProviderMap({ latitude, longitude, name, address }: ProviderMapProps) {
  // Use iframe-based OpenStreetMap to avoid react-leaflet hydration issues
  const mapUrl = `https://www.openstreetmap.org/export/embed.html?bbox=${longitude - 0.01},${latitude - 0.01},${longitude + 0.01},${latitude + 0.01}&layer=mapnik&marker=${latitude},${longitude}`;

  return (
    <div className="relative w-full h-full">
      <iframe
        title={`Map showing location of ${name}`}
        src={mapUrl}
        className="w-full h-full border-0 rounded-lg"
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
      />
      <div className="absolute bottom-2 left-2 right-2 bg-background/90 backdrop-blur-sm rounded-md p-2 text-sm">
        <p className="font-medium truncate">{name}</p>
        <p className="text-muted-foreground text-xs truncate">{address}</p>
      </div>
    </div>
  );
}
