import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Layout } from '@/components/layout/Layout';
import { HeartAnimation } from '@/components/home/HeartAnimation';
import { Building2, User, Search, Heart, Clock, MapPin, Shield, Activity, Phone, ArrowRight, CheckCircle2 } from 'lucide-react';

export default function Home() {
  return (
    <Layout>
      {/* Hero Section with Heart Animation */}
      <section className="relative bg-gradient-hero min-h-[90vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center">
            {/* Heart Animation */}
            <HeartAnimation />
            
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-7xl font-bold text-foreground mb-4 sm:mb-6 animate-fade-in-up px-2">
              Every Drop <span className="text-gradient">Saves Lives</span>
            </h1>
            
            <p className="text-base sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-6 sm:mb-10 animate-fade-in-up animation-delay-100 px-4">
              Connect with hospitals, blood banks, and organizations to find blood when you need it most.
              Real-time availability, verified providers, and location-based search.
            </p>
            
            {/* Emergency Badge */}
            <div className="flex justify-center mb-6 sm:mb-8 animate-fade-in-up animation-delay-200 px-4">
              <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/30 rounded-full px-4 py-2 text-sm backdrop-blur-sm">
                <Activity className="h-4 w-4 text-primary animate-pulse" />
                <span className="text-foreground font-medium">24/7 Emergency Blood Search</span>
              </div>
            </div>
            
            {/* Main CTAs */}
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center mb-6 sm:mb-8 animate-fade-in-up animation-delay-300 px-4">
              <Link to="/auth?tab=signup&role=provider" className="w-full sm:w-auto">
                <Button size="lg" className="w-full sm:w-auto gap-2 text-sm sm:text-lg px-6 sm:px-8 py-5 sm:py-6 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 shadow-lg shadow-primary/30 btn-neon neon-border">
                  <Building2 className="h-4 w-4 sm:h-5 sm:w-5" />
                  <span className="hidden sm:inline">Register as Blood Provider</span>
                  <span className="sm:hidden">Blood Provider</span>
                  <ArrowRight className="h-4 w-4 ml-1" />
                </Button>
              </Link>
              <Link to="/auth?tab=signup&role=seeker" className="w-full sm:w-auto">
                <Button size="lg" variant="outline" className="w-full sm:w-auto gap-2 text-sm sm:text-lg px-6 sm:px-8 py-5 sm:py-6 border-2 border-primary/50 hover:bg-primary/10 hover:border-primary neon-border transition-all duration-300">
                  <User className="h-4 w-4 sm:h-5 sm:w-5" />
                  <span className="hidden sm:inline">Register as Blood Seeker</span>
                  <span className="sm:hidden">Blood Seeker</span>
                </Button>
              </Link>
            </div>
            
            {/* Quick Search */}
            <Link to="/search" className="animate-fade-in-up animation-delay-400 inline-block">
              <Button variant="ghost" size="lg" className="gap-2 text-primary hover:text-primary hover:bg-primary/10">
                <Search className="h-5 w-5" />
                Search for Blood Now
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Trust Indicators */}
      <section className="py-8 bg-secondary/30 border-y border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 sm:flex sm:flex-wrap justify-center items-center gap-6 sm:gap-12 text-muted-foreground">
            <div className="flex items-center gap-2 animate-fade-in">
              <CheckCircle2 className="h-5 w-5 text-success" />
              <span className="text-sm font-medium">Verified Providers</span>
            </div>
            <div className="flex items-center gap-2 animate-fade-in animation-delay-100">
              <Shield className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium">Secure Platform</span>
            </div>
            <div className="flex items-center gap-2 animate-fade-in animation-delay-200">
              <Clock className="h-5 w-5 text-warning" />
              <span className="text-sm font-medium">Real-Time Updates</span>
            </div>
            <div className="flex items-center gap-2 animate-fade-in animation-delay-300">
              <Phone className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium">Direct Contact</span>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 sm:py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-20">
            <h2 className="text-2xl sm:text-3xl md:text-5xl font-bold text-foreground mb-4 animate-fade-in-up">
              Why Choose <span className="text-gradient">BloodBridge</span>?
            </h2>
            <p className="text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto animate-fade-in-up animation-delay-100">
              We bridge the gap between blood seekers and providers with real-time data and verified sources.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="bg-card/50 border-primary/10 card-hover group animate-fade-in-up animation-delay-100 neon-border">
              <CardHeader>
                <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center mb-4 group-hover:scale-110 group-hover:shadow-lg group-hover:shadow-primary/20 transition-all duration-300">
                  <Clock className="h-8 w-8 text-primary" />
                </div>
                <CardTitle className="text-lg">Real-Time Availability</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base text-muted-foreground">
                  Get instant updates on blood availability from verified providers across the region.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="bg-card/50 border-primary/10 card-hover group animate-fade-in-up animation-delay-200 neon-border">
              <CardHeader>
                <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center mb-4 group-hover:scale-110 group-hover:shadow-lg group-hover:shadow-primary/20 transition-all duration-300">
                  <MapPin className="h-8 w-8 text-primary" />
                </div>
                <CardTitle className="text-lg">Location-Based Search</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base text-muted-foreground">
                  Find the nearest blood providers with distance-based sorting and detailed location info.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="bg-card/50 border-primary/10 card-hover group animate-fade-in-up animation-delay-300 neon-border">
              <CardHeader>
                <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center mb-4 group-hover:scale-110 group-hover:shadow-lg group-hover:shadow-primary/20 transition-all duration-300">
                  <Shield className="h-8 w-8 text-primary" />
                </div>
                <CardTitle className="text-lg">Verified Providers</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base text-muted-foreground">
                  All blood providers go through a verification process to ensure authenticity and reliability.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="bg-card/50 border-primary/10 card-hover group animate-fade-in-up animation-delay-400 neon-border">
              <CardHeader>
                <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center mb-4 group-hover:scale-110 group-hover:shadow-lg group-hover:shadow-primary/20 transition-all duration-300">
                  <Heart className="h-8 w-8 text-primary" />
                </div>
                <CardTitle className="text-lg">Save Lives</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base text-muted-foreground">
                  Every connection made through BloodBridge has the potential to save a precious life.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gradient-to-r from-primary/90 to-primary text-primary-foreground relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0" style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M50 30c-5.5 0-10 7.5-10 16.7C40 59 50 70 50 70s10-11 10-23.3c0-9.2-4.5-16.7-10-16.7z' fill='%23ffffff' fill-opacity='0.1'/%3E%3C/svg%3E")`,
            backgroundSize: '50px 50px'
          }} />
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div className="animate-fade-in-up">
              <div className="text-3xl sm:text-5xl font-bold mb-2">50+</div>
              <div className="text-primary-foreground/80 text-sm sm:text-base font-medium">Verified Providers</div>
            </div>
            <div className="animate-fade-in-up animation-delay-100">
              <div className="text-3xl sm:text-5xl font-bold mb-2">8</div>
              <div className="text-primary-foreground/80 text-sm sm:text-base font-medium">Blood Groups</div>
            </div>
            <div className="animate-fade-in-up animation-delay-200">
              <div className="text-3xl sm:text-5xl font-bold mb-2">24/7</div>
              <div className="text-primary-foreground/80 text-sm sm:text-base font-medium">Availability</div>
            </div>
            <div className="animate-fade-in-up animation-delay-300">
              <div className="text-3xl sm:text-5xl font-bold mb-2">India</div>
              <div className="text-primary-foreground/80 text-sm sm:text-base font-medium">Coverage Area</div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 sm:py-24 bg-secondary/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-20">
            <h2 className="text-2xl sm:text-3xl md:text-5xl font-bold text-foreground mb-4 animate-fade-in-up">
              How It Works
            </h2>
            <p className="text-base sm:text-lg text-muted-foreground animate-fade-in-up animation-delay-100">
              Simple steps to find or provide blood
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 lg:gap-16">
            {/* For Seekers */}
            <Card className="p-6 sm:p-8 bg-card/50 border-primary/10 card-hover animate-slide-in-left neon-border">
              <CardHeader className="p-0 mb-6">
                <div className="flex items-center gap-4">
                  <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center shadow-lg shadow-primary/30">
                    <User className="h-7 w-7 text-primary-foreground" />
                  </div>
                  <CardTitle className="text-2xl">For Blood Seekers</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="p-0 space-y-6">
                <div className="flex gap-4 group">
                  <div className="h-12 w-12 rounded-xl bg-primary/20 text-primary flex items-center justify-center font-bold shrink-0 group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
                    1
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground text-lg">Register</h4>
                    <p className="text-muted-foreground">Create an account with your email and basic information</p>
                  </div>
                </div>
                <div className="flex gap-4 group">
                  <div className="h-12 w-12 rounded-xl bg-primary/20 text-primary flex items-center justify-center font-bold shrink-0 group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
                    2
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground text-lg">Search</h4>
                    <p className="text-muted-foreground">Find blood by group and location filters</p>
                  </div>
                </div>
                <div className="flex gap-4 group">
                  <div className="h-12 w-12 rounded-xl bg-primary/20 text-primary flex items-center justify-center font-bold shrink-0 group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
                    3
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground text-lg">Connect</h4>
                    <p className="text-muted-foreground">Contact the provider directly with one click</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* For Providers */}
            <Card className="p-6 sm:p-8 bg-card/50 border-primary/10 card-hover animate-slide-in-right neon-border">
              <CardHeader className="p-0 mb-6">
                <div className="flex items-center gap-4">
                  <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center shadow-lg shadow-primary/30">
                    <Building2 className="h-7 w-7 text-primary-foreground" />
                  </div>
                  <CardTitle className="text-2xl">For Blood Providers</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="p-0 space-y-6">
                <div className="flex gap-4 group">
                  <div className="h-12 w-12 rounded-xl bg-primary/20 text-primary flex items-center justify-center font-bold shrink-0 group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
                    1
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground text-lg">Register</h4>
                    <p className="text-muted-foreground">Submit your organization details and documents</p>
                  </div>
                </div>
                <div className="flex gap-4 group">
                  <div className="h-12 w-12 rounded-xl bg-primary/20 text-primary flex items-center justify-center font-bold shrink-0 group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
                    2
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground text-lg">Get Verified</h4>
                    <p className="text-muted-foreground">Our admin team verifies your credentials</p>
                  </div>
                </div>
                <div className="flex gap-4 group">
                  <div className="h-12 w-12 rounded-xl bg-primary/20 text-primary flex items-center justify-center font-bold shrink-0 group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
                    3
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground text-lg">Manage Stock</h4>
                    <p className="text-muted-foreground">Update your blood inventory in real-time</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 sm:py-24 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="animate-fade-in-up">
            <h2 className="text-2xl sm:text-3xl md:text-5xl font-bold text-foreground mb-6">
              Ready to Make a Difference?
            </h2>
            <p className="text-base sm:text-lg text-muted-foreground mb-10 max-w-2xl mx-auto">
              Join BloodBridge today and be part of a life-saving network that connects those in need with those who can help.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/auth?tab=signup" className="w-full sm:w-auto">
                <Button size="lg" className="w-full sm:w-auto gap-2 px-8 py-6 bg-gradient-to-r from-primary to-primary/80 shadow-lg shadow-primary/30 btn-neon text-base">
                  <Heart className="h-5 w-5" />
                  Join BloodBridge
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <Link to="/search" className="w-full sm:w-auto">
                <Button size="lg" variant="outline" className="w-full sm:w-auto gap-2 px-8 py-6 border-2 border-primary/50 hover:bg-primary/10 neon-border text-base">
                  <Search className="h-5 w-5" />
                  Search Blood Now
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-secondary/30 border-t border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-full bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center shadow-lg shadow-primary/30">
                <Heart className="h-6 w-6 text-primary-foreground fill-primary-foreground" />
              </div>
              <span className="font-bold text-xl">BloodBridge</span>
            </div>
            <p className="text-muted-foreground text-sm text-center">
              © 2024 BloodBridge. Saving lives through connection.
            </p>
            <div className="flex gap-6">
              <Link to="/search" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                Find Blood
              </Link>
              <Link to="/auth" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                Sign In
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </Layout>
  );
}
