import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import { Heart, Menu, X, User, LogOut, LayoutDashboard, Home } from 'lucide-react';
import { useState } from 'react';
import { ADMIN_DASHBOARD_PATH } from '@/config/appRoutes';
import { ThemeToggle } from './ThemeToggle';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

export function Navbar() {
  const { user, role, profile, signOut, loading } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const getDashboardLink = () => {
    switch (role) {
      case 'admin':
        return ADMIN_DASHBOARD_PATH;
      case 'provider':
        return '/provider/dashboard';
      case 'seeker':
        return '/seeker/dashboard';
      default:
        return '/';
    }
  };

  const getInitials = () => {
    if (profile?.full_name) {
      return profile.full_name
        .split(' ')
        .map((n) => n[0])
        .join('')
        .toUpperCase()
        .slice(0, 2);
    }
    return user?.email?.slice(0, 2).toUpperCase() || 'U';
  };

  return (
    <nav className="bg-background/80 backdrop-blur-xl border-b border-primary/10 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex justify-between h-14 sm:h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2 group">
              <div className="h-9 w-9 sm:h-10 sm:w-10 rounded-full bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center shadow-lg shadow-primary/30 group-hover:shadow-primary/50 transition-all duration-300">
                <Heart className="h-4 w-4 sm:h-5 sm:w-5 text-primary-foreground fill-primary-foreground" />
              </div>
              <span className="text-lg sm:text-xl font-bold text-foreground">BloodBridge</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-2">
            <Link to="/">
              <Button variant="ghost" className="hover:bg-primary/10 hover:text-primary">
                <Home className="h-4 w-4 mr-1" /> Home
              </Button>
            </Link>
            <Link to="/search">
              <Button variant="ghost" className="hover:bg-primary/10 hover:text-primary">
                Find Blood
              </Button>
            </Link>
            <ThemeToggle />
            
            {!loading && (
              <>
                {user ? (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="relative h-10 w-10 rounded-full hover:bg-primary/10">
                        <Avatar className="h-10 w-10 border-2 border-primary/30">
                          <AvatarFallback className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
                            {getInitials()}
                          </AvatarFallback>
                        </Avatar>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="w-56 bg-card/95 backdrop-blur-xl border-primary/20" align="end">
                      <div className="flex items-center justify-start gap-2 p-2">
                        <div className="flex flex-col space-y-1 leading-none">
                          <p className="font-medium">{profile?.full_name || 'User'}</p>
                          <p className="text-sm text-muted-foreground">{user.email}</p>
                          <p className="text-xs text-primary capitalize">
                            {role || 'User'}
                          </p>
                        </div>
                      </div>
                      <DropdownMenuSeparator className="bg-primary/10" />
                      <DropdownMenuItem onClick={() => navigate(getDashboardLink())} className="hover:bg-primary/10 cursor-pointer">
                        <LayoutDashboard className="mr-2 h-4 w-4" />
                        Dashboard
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => navigate('/profile')} className="hover:bg-primary/10 cursor-pointer">
                        <User className="mr-2 h-4 w-4" />
                        Profile
                      </DropdownMenuItem>
                      <DropdownMenuSeparator className="bg-primary/10" />
                      <DropdownMenuItem onClick={handleSignOut} className="hover:bg-destructive/10 hover:text-destructive cursor-pointer">
                        <LogOut className="mr-2 h-4 w-4" />
                        Sign out
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                ) : (
                  <div className="flex items-center space-x-2">
                    <Link to="/auth">
                      <Button variant="ghost" className="hover:bg-primary/10 hover:text-primary">
                        Sign In
                      </Button>
                    </Link>
                    <Link to="/auth?tab=signup">
                      <Button className="bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 shadow-lg shadow-primary/30 btn-neon">
                        Get Started
                      </Button>
                    </Link>
                  </div>
                )}
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="hover:bg-primary/10"
            >
              {mobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-primary/10 bg-background/95 backdrop-blur-xl">
          <div className="px-2 pt-2 pb-3 space-y-1">
            <Link
              to="/"
              className="block px-3 py-2 text-base font-medium text-foreground hover:bg-primary/10 hover:text-primary rounded-md transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              to="/search"
              className="block px-3 py-2 text-base font-medium text-foreground hover:bg-primary/10 hover:text-primary rounded-md transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Find Blood
            </Link>
            
            {!loading && (
              <>
                {user ? (
                  <>
                    <Link
                      to={getDashboardLink()}
                      className="block px-3 py-2 text-base font-medium text-foreground hover:bg-primary/10 hover:text-primary rounded-md transition-colors"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Dashboard
                    </Link>
                    <Link
                      to="/profile"
                      className="block px-3 py-2 text-base font-medium text-foreground hover:bg-primary/10 hover:text-primary rounded-md transition-colors"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Profile
                    </Link>
                    <button
                      onClick={() => {
                        handleSignOut();
                        setMobileMenuOpen(false);
                      }}
                      className="block w-full text-left px-3 py-2 text-base font-medium text-foreground hover:bg-destructive/10 hover:text-destructive rounded-md transition-colors"
                    >
                      Sign Out
                    </button>
                  </>
                ) : (
                  <>
                    <Link
                      to="/auth"
                      className="block px-3 py-2 text-base font-medium text-foreground hover:bg-primary/10 hover:text-primary rounded-md transition-colors"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Sign In
                    </Link>
                    <Link
                      to="/auth?tab=signup"
                      className="block px-3 py-2 text-base font-medium text-primary hover:bg-primary/10 rounded-md transition-colors"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Get Started
                    </Link>
                  </>
                )}
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
