import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Loader2 } from 'lucide-react';
import { ADMIN_DASHBOARD_PATH } from '@/config/appRoutes';

export default function Profile() {
  const { user, role, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading) {
      if (!user) {
        navigate('/auth');
        return;
      }
      
      // Redirect to role-specific dashboard which has profile management
      switch (role) {
        case 'admin':
          navigate(ADMIN_DASHBOARD_PATH);
          break;
        case 'provider':
          navigate('/provider/dashboard');
          break;
        case 'seeker':
          navigate('/seeker/dashboard');
          break;
        default:
          navigate('/');
      }
    }
  }, [user, role, loading, navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
    </div>
  );
}
