-- Insert 50 Mumbai demo providers with blood stock
DO $$
DECLARE
  org_ids uuid[] := ARRAY[]::uuid[];
  org_id uuid;
  bg text;
  qty int;
BEGIN
  -- Insert organizations and collect their IDs
  FOR i IN 1..50 LOOP
    INSERT INTO organizations (
      user_id, name, organization_type, phone, email, state, district, city, area, pincode, 
      full_address, latitude, longitude, verification_status, is_demo_provider, verified_at
    ) VALUES (
      gen_random_uuid(),
      CASE i
        WHEN 1 THEN 'Lilavati Hospital Blood Bank'
        WHEN 2 THEN 'Kokilaben Dhirubhai Blood Center'
        WHEN 3 THEN 'Tata Memorial Blood Bank'
        WHEN 4 THEN 'JJ Hospital Blood Bank'
        WHEN 5 THEN 'KEM Hospital Blood Bank'
        WHEN 6 THEN 'Hinduja Hospital Blood Center'
        WHEN 7 THEN 'Nanavati Hospital Blood Bank'
        WHEN 8 THEN 'Breach Candy Blood Bank'
        WHEN 9 THEN 'Bombay Hospital Blood Bank'
        WHEN 10 THEN 'Jaslok Blood Bank'
        WHEN 11 THEN 'Wockhardt Blood Center'
        WHEN 12 THEN 'Saifee Hospital Blood Bank'
        WHEN 13 THEN 'Holy Spirit Blood Bank'
        WHEN 14 THEN 'Seven Hills Blood Center'
        WHEN 15 THEN 'Fortis Mulund Blood Bank'
        WHEN 16 THEN 'Hiranandani Hospital Blood Bank'
        WHEN 17 THEN 'Apollo Blood Bank Navi Mumbai'
        WHEN 18 THEN 'MGM Hospital Blood Center'
        WHEN 19 THEN 'Sterling Hospital Blood Bank'
        WHEN 20 THEN 'AIMS Blood Center Dombivli'
        WHEN 21 THEN 'Indian Red Cross Blood Bank Mumbai'
        WHEN 22 THEN 'Rotary Blood Bank Bandra'
        WHEN 23 THEN 'Lions Blood Bank Andheri'
        WHEN 24 THEN 'Voluntary Blood Bank Dadar'
        WHEN 25 THEN 'Prism Blood Center'
        WHEN 26 THEN 'Think Foundation Blood Bank'
        WHEN 27 THEN 'Regional Blood Bank Thane'
        WHEN 28 THEN 'Sanjeevani Blood Bank Kalyan'
        WHEN 29 THEN 'City Blood Center Panvel'
        WHEN 30 THEN 'Life Blood Bank Kharghar'
        WHEN 31 THEN 'Hope Foundation Blood Services'
        WHEN 32 THEN 'Blood Connect NGO'
        WHEN 33 THEN 'Seva Blood Donation Trust'
        WHEN 34 THEN 'Raktadan Mitra Mandal'
        WHEN 35 THEN 'Youth for Blood NGO'
        WHEN 36 THEN 'Jeevan Raksha Foundation'
        WHEN 37 THEN 'Blood Warriors Mumbai'
        WHEN 38 THEN 'Donate Life Foundation'
        WHEN 39 THEN 'Siddhi Vinayak Blood Services'
        WHEN 40 THEN 'Phoenix Blood Center'
        WHEN 41 THEN 'Gateway Blood Services'
        WHEN 42 THEN 'Marine Drive Blood Center'
        WHEN 43 THEN 'Powai Blood Services'
        WHEN 44 THEN 'Vikhroli Blood Donation Center'
        WHEN 45 THEN 'Ghatkopar Blood Services'
        WHEN 46 THEN 'Chembur Blood Center'
        WHEN 47 THEN 'Versova Blood Services'
        WHEN 48 THEN 'Juhu Blood Donation Center'
        WHEN 49 THEN 'Ghansoli Blood Services'
        WHEN 50 THEN 'Ulwe Blood Center'
      END,
      CASE 
        WHEN i <= 20 THEN 'hospital'
        WHEN i <= 30 THEN 'blood_bank'
        WHEN i <= 38 THEN 'ngo'
        ELSE 'organization'
      END::organization_type,
      '022-' || LPAD((20000000 + i * 100000)::text, 8, '0'),
      'blood' || i || '@demo.bloodconnect.in',
      'Maharashtra',
      CASE 
        WHEN i <= 16 THEN 'Mumbai Suburban'
        WHEN i <= 20 THEN 'Thane'
        WHEN i <= 24 THEN 'Mumbai'
        WHEN i <= 30 THEN 'Thane'
        WHEN i <= 38 THEN 'Mumbai Suburban'
        WHEN i <= 46 THEN 'Mumbai Suburban'
        ELSE 'Thane'
      END,
      CASE 
        WHEN i <= 20 THEN 'Mumbai'
        WHEN i <= 24 THEN 'Mumbai'
        WHEN i = 28 THEN 'Kalyan'
        WHEN i = 29 THEN 'Panvel'
        ELSE 'Navi Mumbai'
      END,
      CASE i
        WHEN 1 THEN 'Bandra West' WHEN 2 THEN 'Andheri West' WHEN 3 THEN 'Parel'
        WHEN 4 THEN 'Byculla' WHEN 5 THEN 'Parel' WHEN 6 THEN 'Mahim'
        WHEN 7 THEN 'Vile Parle West' WHEN 8 THEN 'Breach Candy' WHEN 9 THEN 'Marine Lines'
        WHEN 10 THEN 'Peddar Road' WHEN 11 THEN 'Mira Road' WHEN 12 THEN 'Charni Road'
        WHEN 13 THEN 'Andheri East' WHEN 14 THEN 'Andheri East' WHEN 15 THEN 'Mulund'
        WHEN 16 THEN 'Powai' WHEN 17 THEN 'Belapur' WHEN 18 THEN 'Vashi'
        WHEN 19 THEN 'Nerul' WHEN 20 THEN 'Dombivli' WHEN 21 THEN 'Fort'
        WHEN 22 THEN 'Bandra East' WHEN 23 THEN 'Andheri West' WHEN 24 THEN 'Dadar'
        WHEN 25 THEN 'Borivali' WHEN 26 THEN 'Goregaon' WHEN 27 THEN 'Thane West'
        WHEN 28 THEN 'Kalyan West' WHEN 29 THEN 'Panvel' WHEN 30 THEN 'Kharghar'
        WHEN 31 THEN 'Malad' WHEN 32 THEN 'Kandivali' WHEN 33 THEN 'Worli'
        WHEN 34 THEN 'Girgaon' WHEN 35 THEN 'Santacruz' WHEN 36 THEN 'Jogeshwari'
        WHEN 37 THEN 'Thane East' WHEN 38 THEN 'Airoli' WHEN 39 THEN 'Lower Parel'
        WHEN 40 THEN 'Kurla' WHEN 41 THEN 'Colaba' WHEN 42 THEN 'Churchgate'
        WHEN 43 THEN 'Powai' WHEN 44 THEN 'Vikhroli' WHEN 45 THEN 'Ghatkopar'
        WHEN 46 THEN 'Chembur' WHEN 47 THEN 'Versova' WHEN 48 THEN 'Juhu'
        WHEN 49 THEN 'Ghansoli' ELSE 'Ulwe'
      END,
      CASE 
        WHEN i <= 10 THEN '40000' || i
        WHEN i <= 20 THEN '40006' || (i - 10)
        WHEN i <= 30 THEN '40070' || (i - 20)
        WHEN i <= 40 THEN '40005' || (i - 30)
        ELSE '40007' || (i - 40)
      END,
      'Demo Address ' || i || ', Mumbai, Maharashtra',
      -- Latitude (Mumbai area with specific coordinates)
      CASE i
        WHEN 1 THEN 19.0509 WHEN 2 THEN 19.1308 WHEN 3 THEN 19.0042
        WHEN 4 THEN 18.9629 WHEN 5 THEN 19.0002 WHEN 6 THEN 19.0360
        WHEN 7 THEN 19.1015 WHEN 8 THEN 18.9712 WHEN 9 THEN 18.9438
        WHEN 10 THEN 18.9731 WHEN 11 THEN 19.2813 WHEN 12 THEN 18.9545
        WHEN 13 THEN 19.1220 WHEN 14 THEN 19.1185 WHEN 15 THEN 19.1724
        WHEN 16 THEN 19.1187 WHEN 17 THEN 19.0200 WHEN 18 THEN 19.0763
        WHEN 19 THEN 19.0330 WHEN 20 THEN 19.2167 WHEN 21 THEN 18.9325
        WHEN 22 THEN 19.0652 WHEN 23 THEN 19.1363 WHEN 24 THEN 19.0178
        WHEN 25 THEN 19.2307 WHEN 26 THEN 19.1550 WHEN 27 THEN 19.1970
        WHEN 28 THEN 19.2437 WHEN 29 THEN 18.9940 WHEN 30 THEN 19.0406
        WHEN 31 THEN 19.1854 WHEN 32 THEN 19.2031 WHEN 33 THEN 19.0098
        WHEN 34 THEN 18.9543 WHEN 35 THEN 19.0807 WHEN 36 THEN 19.1360
        WHEN 37 THEN 19.2360 WHEN 38 THEN 19.1520 WHEN 39 THEN 18.9948
        WHEN 40 THEN 19.0726 WHEN 41 THEN 18.9067 WHEN 42 THEN 18.9352
        WHEN 43 THEN 19.1178 WHEN 44 THEN 19.1104 WHEN 45 THEN 19.0860
        WHEN 46 THEN 19.0522 WHEN 47 THEN 19.1320 WHEN 48 THEN 19.0968
        WHEN 49 THEN 19.1165 ELSE 18.9732
      END,
      -- Longitude (Mumbai area with specific coordinates)
      CASE i
        WHEN 1 THEN 72.8264 WHEN 2 THEN 72.8260 WHEN 3 THEN 72.8426
        WHEN 4 THEN 72.8355 WHEN 5 THEN 72.8415 WHEN 6 THEN 72.8400
        WHEN 7 THEN 72.8439 WHEN 8 THEN 72.8050 WHEN 9 THEN 72.8260
        WHEN 10 THEN 72.8096 WHEN 11 THEN 72.8683 WHEN 12 THEN 72.8192
        WHEN 13 THEN 72.8698 WHEN 14 THEN 72.8808 WHEN 15 THEN 72.9570
        WHEN 16 THEN 72.9060 WHEN 17 THEN 73.0352 WHEN 18 THEN 72.9980
        WHEN 19 THEN 73.0180 WHEN 20 THEN 73.0833 WHEN 21 THEN 72.8315
        WHEN 22 THEN 72.8656 WHEN 23 THEN 72.8296 WHEN 24 THEN 72.8478
        WHEN 25 THEN 72.8567 WHEN 26 THEN 72.8497 WHEN 27 THEN 72.9637
        WHEN 28 THEN 73.1355 WHEN 29 THEN 73.1180 WHEN 30 THEN 73.0712
        WHEN 31 THEN 72.8494 WHEN 32 THEN 72.8371 WHEN 33 THEN 72.8174
        WHEN 34 THEN 72.8137 WHEN 35 THEN 72.8386 WHEN 36 THEN 72.8500
        WHEN 37 THEN 72.9780 WHEN 38 THEN 72.9967 WHEN 39 THEN 72.8260
        WHEN 40 THEN 72.8792 WHEN 41 THEN 72.8147 WHEN 42 THEN 72.8267
        WHEN 43 THEN 72.9063 WHEN 44 THEN 72.9222 WHEN 45 THEN 72.9080
        WHEN 46 THEN 72.8960 WHEN 47 THEN 72.8180 WHEN 48 THEN 72.8260
        WHEN 49 THEN 72.9956 ELSE 73.0230
      END,
      'approved',
      true,
      NOW()
    ) RETURNING id INTO org_id;
    
    org_ids := array_append(org_ids, org_id);
  END LOOP;

  -- Insert blood stock for each organization
  FOREACH org_id IN ARRAY org_ids LOOP
    FOREACH bg IN ARRAY ARRAY['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] LOOP
      -- Random quantity between 5 and 50
      qty := 5 + floor(random() * 46)::int;
      INSERT INTO blood_stock (organization_id, blood_group, quantity)
      VALUES (org_id, bg::blood_group, qty);
    END LOOP;
  END LOOP;
END $$;