import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, TrendingUp, Droplets, Users, Building2 } from 'lucide-react';
import { BLOOD_GROUPS } from '@/types';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';

interface BloodStockByGroup {
  blood_group: string;
  quantity: number;
}

interface ProvidersByDistrict {
  district: string;
  count: number;
}

interface SearchesByBloodGroup {
  blood_group: string;
  count: number;
}

const COLORS = ['#dc2626', '#ea580c', '#d97706', '#65a30d', '#16a34a', '#0891b2', '#2563eb', '#7c3aed'];

export function AnalyticsDashboard() {
  const [loading, setLoading] = useState(true);
  const [bloodStockData, setBloodStockData] = useState<BloodStockByGroup[]>([]);
  const [providersByDistrict, setProvidersByDistrict] = useState<ProvidersByDistrict[]>([]);
  const [searchesByBloodGroup, setSearchesByBloodGroup] = useState<SearchesByBloodGroup[]>([]);
  const [recentRegistrations, setRecentRegistrations] = useState({
    users: 0,
    providers: 0,
  });

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    try {
      // Fetch blood stock by group
      const { data: stockData } = await supabase
        .from('blood_stock')
        .select('blood_group, quantity');

      if (stockData) {
        const groupedStock = BLOOD_GROUPS.map(bg => ({
          blood_group: bg,
          quantity: stockData
            .filter(s => s.blood_group === bg)
            .reduce((sum, s) => sum + s.quantity, 0),
        }));
        setBloodStockData(groupedStock);
      }

      // Fetch providers by district
      const { data: orgsData } = await supabase
        .from('organizations')
        .select('district')
        .eq('verification_status', 'approved');

      if (orgsData) {
        const districtCounts = orgsData.reduce((acc, org) => {
          acc[org.district] = (acc[org.district] || 0) + 1;
          return acc;
        }, {} as Record<string, number>);

        const sortedDistricts = Object.entries(districtCounts)
          .map(([district, count]) => ({ district, count }))
          .sort((a, b) => b.count - a.count)
          .slice(0, 10);

        setProvidersByDistrict(sortedDistricts);
      }

      // Fetch searches by blood group
      const { data: searchData } = await supabase
        .from('search_history')
        .select('blood_group');

      if (searchData) {
        const searchCounts = BLOOD_GROUPS.map(bg => ({
          blood_group: bg,
          count: searchData.filter(s => s.blood_group === bg).length,
        }));
        setSearchesByBloodGroup(searchCounts);
      }

      // Fetch recent registrations (last 30 days)
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

      const { count: recentUsers } = await supabase
        .from('profiles')
        .select('id', { count: 'exact' })
        .gte('created_at', thirtyDaysAgo.toISOString());

      const { count: recentProviders } = await supabase
        .from('organizations')
        .select('id', { count: 'exact' })
        .gte('created_at', thirtyDaysAgo.toISOString());

      setRecentRegistrations({
        users: recentUsers || 0,
        providers: recentProviders || 0,
      });
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">New Users (30 days)</p>
                <p className="text-2xl font-bold">{recentRegistrations.users}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Building2 className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">New Providers (30 days)</p>
                <p className="text-2xl font-bold">{recentRegistrations.providers}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Blood Stock Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Droplets className="h-5 w-5" />
            Total Blood Stock by Group
          </CardTitle>
          <CardDescription>Current inventory across all approved providers</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={bloodStockData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="blood_group" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--background))', 
                    border: '1px solid hsl(var(--border))' 
                  }} 
                />
                <Bar dataKey="quantity" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Search Demand */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Blood Search Demand
            </CardTitle>
            <CardDescription>Most searched blood groups</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={searchesByBloodGroup.filter(s => s.count > 0)}
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="count"
                    nameKey="blood_group"
                    label={({ blood_group }) => blood_group}
                  >
                    {searchesByBloodGroup.map((entry, index) => (
                      <Cell key={entry.blood_group} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Providers by District */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Top Districts by Providers
            </CardTitle>
            <CardDescription>Approved providers per district</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={providersByDistrict} layout="vertical" margin={{ top: 5, right: 30, left: 60, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis type="number" className="text-xs" />
                  <YAxis type="category" dataKey="district" className="text-xs" width={55} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--background))', 
                      border: '1px solid hsl(var(--border))' 
                    }} 
                  />
                  <Bar dataKey="count" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
