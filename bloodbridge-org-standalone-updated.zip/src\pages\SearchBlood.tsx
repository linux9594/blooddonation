import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Layout } from '@/components/layout/Layout';
import { BloodSearchForm } from '@/components/search/BloodSearchForm';
import { SearchResultCard } from '@/components/search/SearchResultCard';
import { SearchFilters, OrganizationWithStock, BloodGroup } from '@/types';
import { toast } from 'sonner';
import { Search, AlertCircle, Heart, MapPin, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

// Haversine formula to calculate distance between two coordinates in km
function calculateDistance(
  lat1: number | null, 
  lon1: number | null, 
  lat2: number | null, 
  lon2: number | null
): number {
  if (lat1 === null || lon1 === null || lat2 === null || lon2 === null) {
    return Infinity;
  }
  
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

const DISTRICT_COORDINATES: Record<string, { lat: number; lon: number }> = {
  'Mumbai': { lat: 19.0760, lon: 72.8777 },
  'Mumbai Suburban': { lat: 19.1136, lon: 72.8697 },
  'Thane': { lat: 19.2183, lon: 72.9781 },
  'Pune': { lat: 18.5204, lon: 73.8567 },
  'Nagpur': { lat: 21.1458, lon: 79.0882 },
  'Nashik': { lat: 19.9975, lon: 73.7898 },
  'Aurangabad': { lat: 19.8762, lon: 75.3433 },
  'Solapur': { lat: 17.6599, lon: 75.9064 },
  'Kolhapur': { lat: 16.7050, lon: 74.2433 },
  'Sangli': { lat: 16.8524, lon: 74.5815 },
  'Satara': { lat: 17.6805, lon: 74.0183 },
  'Ratnagiri': { lat: 16.9944, lon: 73.3000 },
  'Sindhudurg': { lat: 16.3489, lon: 73.5356 },
  'Ahmednagar': { lat: 19.0948, lon: 74.7480 },
  'Beed': { lat: 18.9891, lon: 75.7531 },
  'Jalna': { lat: 19.8347, lon: 75.8816 },
  'Latur': { lat: 18.4088, lon: 76.5604 },
  'Osmanabad': { lat: 18.1860, lon: 76.0420 },
  'Nanded': { lat: 19.1383, lon: 77.3210 },
  'Parbhani': { lat: 19.2704, lon: 76.7747 },
  'Hingoli': { lat: 19.7173, lon: 77.1461 },
  'Akola': { lat: 20.7059, lon: 77.0085 },
  'Amravati': { lat: 20.9374, lon: 77.7796 },
  'Buldhana': { lat: 20.5299, lon: 76.1784 },
  'Washim': { lat: 20.1033, lon: 77.1339 },
  'Yavatmal': { lat: 20.3888, lon: 78.1204 },
  'Bhandara': { lat: 21.1669, lon: 79.6510 },
  'Chandrapur': { lat: 19.9615, lon: 79.2961 },
  'Gadchiroli': { lat: 20.1809, lon: 80.0005 },
  'Gondia': { lat: 21.4547, lon: 80.1927 },
  'Wardha': { lat: 20.7453, lon: 78.6022 },
  'Dhule': { lat: 20.9042, lon: 74.7749 },
  'Jalgaon': { lat: 21.0077, lon: 75.5626 },
  'Nandurbar': { lat: 21.3698, lon: 74.2399 },
  'Palghar': { lat: 19.6969, lon: 72.7654 },
  'Raigad': { lat: 18.5158, lon: 73.1822 },
};

export default function SearchBlood() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [results, setResults] = useState<(OrganizationWithStock & { distance?: number })[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [searchedBloodGroup, setSearchedBloodGroup] = useState<BloodGroup | null>(null);
  const [searchedLocation, setSearchedLocation] = useState<string>('');

  const handleSearch = async (filters: SearchFilters) => {
    // Check if user is logged in
    if (!user) {
      toast.error('Please login to search for blood');
      navigate('/auth');
      return;
    }

    if (!filters.blood_group) {
      toast.error('Please select a blood group');
      return;
    }

    setLoading(true);
    setSearched(true);
    setSearchedBloodGroup(filters.blood_group);
    setSearchedLocation(filters.district || filters.city || 'Maharashtra');

    try {
      const { data, error } = await supabase
        .from('organizations')
        .select(`
          id, name, organization_type, city, district, state, pincode, latitude, longitude, is_demo_provider, phone,
          blood_stock (blood_group, quantity)
        `)
        .or('verification_status.eq.approved,is_demo_provider.eq.true');

      if (error) throw error;

      const referenceCoords = filters.district 
        ? DISTRICT_COORDINATES[filters.district] || { lat: 19.0760, lon: 72.8777 }
        : { lat: 19.0760, lon: 72.8777 };

      const orgsWithStock = (data || [])
        .map((org) => {
          const distance = calculateDistance(
            referenceCoords.lat,
            referenceCoords.lon,
            org.latitude,
            org.longitude
          );
          return {
            ...org,
            blood_stock: org.blood_stock || [],
            distance: isFinite(distance) ? Math.round(distance) : null,
          };
        })
        .filter((org) => {
          const stock = org.blood_stock.find(
            (s: any) => s.blood_group === filters.blood_group
          );
          return stock && stock.quantity > 0;
        })
        .sort((a, b) => {
          const distA = a.distance ?? Infinity;
          const distB = b.distance ?? Infinity;
          return distA - distB;
        }) as (OrganizationWithStock & { distance?: number })[];

      setResults(orgsWithStock);

      await supabase.from('search_history').insert({
        user_id: user.id,
        blood_group: filters.blood_group,
        state: filters.state,
        district: filters.district || null,
        city: filters.city || null,
        pincode: filters.pincode || null,
        results_count: orgsWithStock.length,
      });

      if (orgsWithStock.length === 0) {
        toast.info('No providers found with the selected blood group in stock');
      } else {
        toast.success(`Found ${orgsWithStock.length} provider(s) with ${filters.blood_group} blood`);
      }
    } catch (error) {
      console.error('Error searching blood:', error);
      toast.error('Failed to search. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Show login prompt if not authenticated
  if (!authLoading && !user) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center p-4">
          <Card className="max-w-md w-full p-8 text-center bg-card/80 backdrop-blur-sm border-primary/20">
            <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
              <Lock className="h-10 w-10 text-primary" />
            </div>
            <h2 className="text-2xl font-bold text-foreground mb-2">Login Required</h2>
            <p className="text-muted-foreground mb-6">
              Please login or create an account to search for blood availability.
            </p>
            <div className="flex flex-col gap-3">
              <Button 
                onClick={() => navigate('/auth')}
                className="w-full bg-primary hover:bg-primary/90 btn-neon"
              >
                Login / Register
              </Button>
              <Button 
                variant="outline"
                onClick={() => navigate('/')}
                className="w-full border-primary/30 hover:bg-primary/10"
              >
                Go to Home
              </Button>
            </div>
          </Card>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="min-h-screen">
        {/* Hero Header */}
        <div className="bg-gradient-to-b from-primary/10 to-transparent py-8 sm:py-12 mb-4 sm:mb-8">
          <div className="container mx-auto px-3 sm:px-4">
            <div className="flex items-center gap-3 sm:gap-4 mb-2">
              <div className="h-12 w-12 sm:h-14 sm:w-14 rounded-2xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center shadow-lg shadow-primary/30">
                <Heart className="h-6 w-6 sm:h-7 sm:w-7 text-primary-foreground fill-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-foreground">
                  Find Blood
                </h1>
                <p className="text-sm sm:text-base text-muted-foreground">
                  Search blood availability across Maharashtra
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-3 sm:px-4 pb-8">
          <BloodSearchForm onSearch={handleSearch} loading={loading} />

          {/* Search Results */}
          <div className="mt-6 sm:mt-8">
            {loading ? (
              <div className="flex items-center justify-center py-12 sm:py-16">
                <div className="text-center">
                  <div className="relative">
                    <div className="h-16 w-16 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto" />
                    <Heart className="h-6 w-6 text-primary absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-pulse" />
                  </div>
                  <p className="text-sm sm:text-base text-muted-foreground mt-4">Searching for blood availability...</p>
                </div>
              </div>
            ) : searched ? (
              results.length > 0 ? (
                <div className="space-y-4 sm:space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 p-4 rounded-xl bg-card/50 border border-primary/20">
                    <div>
                      <h2 className="text-lg sm:text-xl font-semibold text-foreground">
                        {results.length} Provider{results.length > 1 ? 's' : ''} Found
                      </h2>
                      <div className="flex items-center gap-2 text-xs sm:text-sm text-muted-foreground mt-1">
                        <MapPin className="h-3 w-3 sm:h-4 sm:w-4" />
                        <span>Sorted by distance from {searchedLocation}</span>
                      </div>
                    </div>
                    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20">
                      <span className="text-sm font-medium text-primary">{searchedBloodGroup}</span>
                      <span className="text-xs text-muted-foreground">blood type</span>
                    </div>
                  </div>
                  <div className="grid gap-4">
                    {results.map((org) => (
                      <SearchResultCard
                        key={org.id}
                        organization={org}
                        searchedBloodGroup={searchedBloodGroup!}
                        distance={org.distance}
                      />
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 sm:py-16">
                  <div className="h-20 w-20 rounded-full bg-secondary/50 flex items-center justify-center mx-auto mb-4">
                    <AlertCircle className="h-10 w-10 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg sm:text-xl font-medium text-foreground">No providers found</h3>
                  <p className="text-sm text-muted-foreground mt-2 max-w-md mx-auto">
                    No blood banks or hospitals have <span className="text-primary font-medium">{searchedBloodGroup}</span> blood in stock.
                    <br />
                    Try checking back later or search for a different blood group.
                  </p>
                </div>
              )
            ) : (
              <div className="text-center py-12 sm:py-16">
                <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4 animate-pulse">
                  <Search className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-lg sm:text-xl font-medium text-foreground">Search for Blood</h3>
                <p className="text-sm text-muted-foreground mt-2 max-w-md mx-auto">
                  Select a blood group and optionally a location to find available blood providers near you
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
