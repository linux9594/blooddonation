-- Fix the function search path issue
CREATE OR REPLACE FUNCTION public.handle_new_user_role()
RETURNS TRIGGER AS $$
BEGIN
  -- This function will be called from the client after signup
  -- Just validate the role is allowed
  IF NEW.role NOT IN ('provider', 'seeker') THEN
    RAISE EXCEPTION 'Invalid role. Only provider or seeker roles are allowed for self-registration.';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;