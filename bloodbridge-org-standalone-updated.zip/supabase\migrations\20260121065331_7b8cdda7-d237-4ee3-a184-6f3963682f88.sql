-- Drop the foreign key constraint on organizations.user_id if it exists
-- This allows demo providers to be inserted without corresponding auth.users entries
ALTER TABLE organizations DROP CONSTRAINT IF EXISTS organizations_user_id_fkey;