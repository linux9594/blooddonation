-- Drop the existing restrictive INSERT policy
DROP POLICY IF EXISTS "Users can insert their own role on registration" ON public.user_roles;

-- Create a new INSERT policy that allows users to insert their own role
-- The key is using auth.uid() which returns the user's ID even during signup process
CREATE POLICY "Users can insert their own role on registration" 
ON public.user_roles 
FOR INSERT 
TO authenticated
WITH CHECK (
  auth.uid() = user_id 
  AND role IN ('provider'::app_role, 'seeker'::app_role)
);

-- Also create a policy for the anon role to handle the brief moment during signup
-- This uses the service role key approach instead, so we'll use a trigger

-- Create a function to automatically assign role after user creation
CREATE OR REPLACE FUNCTION public.handle_new_user_role()
RETURNS TRIGGER AS $$
BEGIN
  -- This function will be called from the client after signup
  -- Just validate the role is allowed
  IF NEW.role NOT IN ('provider', 'seeker') THEN
    RAISE EXCEPTION 'Invalid role. Only provider or seeker roles are allowed for self-registration.';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for role validation
DROP TRIGGER IF EXISTS validate_user_role ON public.user_roles;
CREATE TRIGGER validate_user_role
BEFORE INSERT ON public.user_roles
FOR EACH ROW
EXECUTE FUNCTION public.handle_new_user_role();