import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { BLOOD_GROUPS, BloodGroup, BloodStock } from '@/types';
import { Droplet, Save, Loader2 } from 'lucide-react';

interface BloodStockGridProps {
  organizationId: string;
}

export function BloodStockGrid({ organizationId }: BloodStockGridProps) {
  const [stocks, setStocks] = useState<Record<BloodGroup, number>>({} as Record<BloodGroup, number>);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);

  useEffect(() => {
    fetchBloodStock();
  }, [organizationId]);

  const fetchBloodStock = async () => {
    try {
      const { data, error } = await supabase
        .from('blood_stock')
        .select('*')
        .eq('organization_id', organizationId);

      if (error) throw error;

      const stockMap: Record<BloodGroup, number> = {} as Record<BloodGroup, number>;
      let latestUpdate: string | null = null;

      BLOOD_GROUPS.forEach((bg) => {
        const stock = data?.find((s) => s.blood_group === bg);
        stockMap[bg] = stock?.quantity || 0;
        if (stock?.last_updated && (!latestUpdate || stock.last_updated > latestUpdate)) {
          latestUpdate = stock.last_updated;
        }
      });

      setStocks(stockMap);
      setLastUpdated(latestUpdate);
    } catch (error) {
      console.error('Error fetching blood stock:', error);
      toast.error('Failed to load blood stock');
    } finally {
      setLoading(false);
    }
  };

  const updateStock = (bloodGroup: BloodGroup, value: string) => {
    const quantity = parseInt(value) || 0;
    setStocks((prev) => ({ ...prev, [bloodGroup]: Math.max(0, quantity) }));
  };

  const saveAllStock = async () => {
    setSaving(true);
    try {
      const updates = BLOOD_GROUPS.map(async (bloodGroup) => {
        const { data: existing } = await supabase
          .from('blood_stock')
          .select('id')
          .eq('organization_id', organizationId)
          .eq('blood_group', bloodGroup)
          .single();

        if (existing) {
          return supabase
            .from('blood_stock')
            .update({ quantity: stocks[bloodGroup], last_updated: new Date().toISOString() })
            .eq('id', existing.id);
        } else {
          return supabase
            .from('blood_stock')
            .insert({
              organization_id: organizationId,
              blood_group: bloodGroup,
              quantity: stocks[bloodGroup],
            });
        }
      });

      await Promise.all(updates);
      setLastUpdated(new Date().toISOString());
      toast.success('Blood stock updated successfully');
    } catch (error) {
      console.error('Error saving blood stock:', error);
      toast.error('Failed to update blood stock');
    } finally {
      setSaving(false);
    }
  };

  const getStockLevel = (quantity: number) => {
    if (quantity === 0) return 'unavailable';
    if (quantity <= 5) return 'low';
    return 'available';
  };

  const getStockColor = (level: string) => {
    switch (level) {
      case 'available':
        return 'bg-success/10 border-success text-success';
      case 'low':
        return 'bg-warning/10 border-warning text-warning';
      default:
        return 'bg-destructive/10 border-destructive text-destructive';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Droplet className="h-5 w-5 text-primary" />
              Blood Stock Management
            </CardTitle>
            <CardDescription>
              Update the quantity of blood bottles available for each blood group
            </CardDescription>
          </div>
          <Button onClick={saveAllStock} disabled={saving}>
            {saving ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Save className="mr-2 h-4 w-4" />
            )}
            Save All
          </Button>
        </div>
        {lastUpdated && (
          <p className="text-xs text-muted-foreground mt-2">
            Last updated: {new Date(lastUpdated).toLocaleString()}
          </p>
        )}
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {BLOOD_GROUPS.map((bloodGroup) => {
            const level = getStockLevel(stocks[bloodGroup]);
            return (
              <div
                key={bloodGroup}
                className={`p-4 rounded-lg border-2 ${getStockColor(level)}`}
              >
                <div className="text-center mb-2">
                  <span className="text-2xl font-bold">{bloodGroup}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    min="0"
                    value={stocks[bloodGroup]}
                    onChange={(e) => updateStock(bloodGroup, e.target.value)}
                    className="text-center font-medium"
                  />
                  <span className="text-sm">units</span>
                </div>
                <p className="text-xs text-center mt-2 capitalize">{level}</p>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
