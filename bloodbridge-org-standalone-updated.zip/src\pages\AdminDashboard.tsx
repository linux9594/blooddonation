import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Layout } from '@/components/layout/Layout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { Loader2, Users, Building2, Droplets, CheckCircle, Clock, XCircle } from 'lucide-react';
import { PendingApprovals } from '@/components/admin/PendingApprovals';
import { UserManagement } from '@/components/admin/UserManagement';
import { ProviderManagement } from '@/components/admin/ProviderManagement';
import { AnalyticsDashboard } from '@/components/admin/AnalyticsDashboard';
import { AuditLog } from '@/components/admin/AuditLog';
import { ADMIN_AUTH_PATH } from '@/config/appRoutes';

interface Stats {
  totalUsers: number;
  totalProviders: number;
  pendingApprovals: number;
  approvedProviders: number;
  rejectedProviders: number;
  totalBloodStock: number;
}

export default function AdminDashboard() {
  const { user, role, loading } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState<Stats>({
    totalUsers: 0,
    totalProviders: 0,
    pendingApprovals: 0,
    approvedProviders: 0,
    rejectedProviders: 0,
    totalBloodStock: 0,
  });
  const [statsLoading, setStatsLoading] = useState(true);

  useEffect(() => {
    if (!loading && !user) {
      navigate(ADMIN_AUTH_PATH);
    } else if (!loading && role !== 'admin') {
      navigate('/');
    }
  }, [user, role, loading, navigate]);

  useEffect(() => {
    if (user && role === 'admin') {
      fetchStats();
    }
  }, [user, role]);

  const fetchStats = async () => {
    try {
      const [usersResult, orgsResult, stockResult] = await Promise.all([
        supabase.from('profiles').select('id', { count: 'exact' }),
        supabase.from('organizations').select('verification_status'),
        supabase.from('blood_stock').select('quantity'),
      ]);

      const pending = orgsResult.data?.filter(o => o.verification_status === 'pending').length || 0;
      const approved = orgsResult.data?.filter(o => o.verification_status === 'approved').length || 0;
      const rejected = orgsResult.data?.filter(o => o.verification_status === 'rejected').length || 0;
      const totalStock = stockResult.data?.reduce((sum, s) => sum + s.quantity, 0) || 0;

      setStats({
        totalUsers: usersResult.count || 0,
        totalProviders: orgsResult.data?.length || 0,
        pendingApprovals: pending,
        approvedProviders: approved,
        rejectedProviders: rejected,
        totalBloodStock: totalStock,
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setStatsLoading(false);
    }
  };

  if (loading || !user || role !== 'admin') {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[50vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Admin Dashboard</h1>
          <p className="text-muted-foreground mt-2">
            Manage providers, users, and monitor platform analytics
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Users</p>
                  <p className="text-2xl font-bold">
                    {statsLoading ? '-' : stats.totalUsers}
                  </p>
                </div>
                <Users className="h-8 w-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Providers</p>
                  <p className="text-2xl font-bold">
                    {statsLoading ? '-' : stats.totalProviders}
                  </p>
                </div>
                <Building2 className="h-8 w-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-yellow-50 dark:bg-yellow-950/20">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Pending</p>
                  <p className="text-2xl font-bold text-yellow-600">
                    {statsLoading ? '-' : stats.pendingApprovals}
                  </p>
                </div>
                <Clock className="h-8 w-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-green-50 dark:bg-green-950/20">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Approved</p>
                  <p className="text-2xl font-bold text-green-600">
                    {statsLoading ? '-' : stats.approvedProviders}
                  </p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-red-50 dark:bg-red-950/20">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Rejected</p>
                  <p className="text-2xl font-bold text-destructive">
                    {statsLoading ? '-' : stats.rejectedProviders}
                  </p>
                </div>
                <XCircle className="h-8 w-8 text-destructive" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Blood Units</p>
                  <p className="text-2xl font-bold">
                    {statsLoading ? '-' : stats.totalBloodStock}
                  </p>
                </div>
                <Droplets className="h-8 w-8 text-primary" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="pending" className="space-y-6">
          <TabsList className="w-full flex flex-wrap justify-start gap-1 h-auto p-1">
            <TabsTrigger value="pending" className="text-xs sm:text-sm px-2 sm:px-4 py-1.5 sm:py-2">Approvals</TabsTrigger>
            <TabsTrigger value="providers" className="text-xs sm:text-sm px-2 sm:px-4 py-1.5 sm:py-2">Providers</TabsTrigger>
            <TabsTrigger value="users" className="text-xs sm:text-sm px-2 sm:px-4 py-1.5 sm:py-2">Users</TabsTrigger>
            <TabsTrigger value="analytics" className="text-xs sm:text-sm px-2 sm:px-4 py-1.5 sm:py-2">Analytics</TabsTrigger>
            <TabsTrigger value="audit" className="text-xs sm:text-sm px-2 sm:px-4 py-1.5 sm:py-2">Audit Log</TabsTrigger>
          </TabsList>

          <TabsContent value="pending">
            <PendingApprovals onUpdate={fetchStats} showRejected={true} />
          </TabsContent>

          <TabsContent value="providers">
            <ProviderManagement onUpdate={fetchStats} />
          </TabsContent>

          <TabsContent value="users">
            <UserManagement />
          </TabsContent>

          <TabsContent value="analytics">
            <AnalyticsDashboard />
          </TabsContent>

          <TabsContent value="audit">
            <AuditLog />
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
