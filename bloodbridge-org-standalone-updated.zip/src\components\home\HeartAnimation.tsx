import { useEffect, useRef, useState, useCallback } from 'react';

interface HeartAnimationProps {
  onSoundToggle?: (playing: boolean) => void;
}

export function HeartAnimation({ onSoundToggle }: HeartAnimationProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [beatPhase, setBeatPhase] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const beatIntervalRef = useRef<NodeJS.Timeout>();

  // Heartbeat timing - matches a real heartbeat pattern
  const BEAT_DURATION = 800; // ms for one heartbeat cycle
  const CONTRACTION_TIME = 150; // ms for the contraction phase

  useEffect(() => {
    audioRef.current = new Audio('/sounds/heartbeat.mp4');
    audioRef.current.loop = true;
    audioRef.current.volume = 0.4;

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      if (beatIntervalRef.current) {
        clearInterval(beatIntervalRef.current);
      }
    };
  }, []);

  // Sync animation with heartbeat
  const startBeatAnimation = useCallback(() => {
    let phase = 0;
    const animate = () => {
      setBeatPhase(phase);
      phase = (phase + 1) % 100;
    };
    
    // Update beat phase every 8ms for smooth animation
    beatIntervalRef.current = setInterval(animate, BEAT_DURATION / 100);
  }, []);

  const stopBeatAnimation = useCallback(() => {
    if (beatIntervalRef.current) {
      clearInterval(beatIntervalRef.current);
    }
    setBeatPhase(0);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = canvas.offsetWidth * window.devicePixelRatio;
      canvas.height = canvas.offsetHeight * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    let time = 0;
    const lines: { x: number; speed: number; amplitude: number; phase: number }[] = [];
    
    for (let i = 0; i < 3; i++) {
      lines.push({
        x: -200 - i * 300,
        speed: 3 + Math.random() * 0.5,
        amplitude: 30 + Math.random() * 15,
        phase: Math.random() * Math.PI * 2,
      });
    }

    const drawECG = (x: number, y: number, width: number, amplitude: number, phase: number) => {
      ctx.beginPath();
      ctx.moveTo(x, y);

      for (let i = 0; i < width; i++) {
        const progress = i / width;
        let ecgY = y;

        const segment = (progress * 10 + phase) % 10;
        
        if (segment < 1) {
          // P wave
          ecgY = y - Math.sin(segment * Math.PI) * amplitude * 0.3;
        } else if (segment < 2) {
          ecgY = y;
        } else if (segment < 2.5) {
          // Q wave
          ecgY = y + (segment - 2) * amplitude * 0.4;
        } else if (segment < 3) {
          // R wave (main spike up)
          ecgY = y - (segment - 2.5) * amplitude * 4;
        } else if (segment < 3.5) {
          // R wave coming down
          ecgY = y - (3.5 - segment) * amplitude * 4;
        } else if (segment < 4) {
          // S wave
          ecgY = y + (4 - segment) * amplitude * 0.6;
        } else if (segment < 6) {
          // T wave
          ecgY = y - Math.sin((segment - 4) * Math.PI / 2) * amplitude * 0.5;
        } else {
          ecgY = y;
        }

        ctx.lineTo(x + i, ecgY);
      }

      const gradient = ctx.createLinearGradient(x, 0, x + width, 0);
      gradient.addColorStop(0, 'rgba(255, 0, 0, 0)');
      gradient.addColorStop(0.2, 'rgba(255, 50, 50, 0.95)');
      gradient.addColorStop(0.8, 'rgba(255, 50, 50, 0.95)');
      gradient.addColorStop(1, 'rgba(255, 0, 0, 0)');
      
      ctx.strokeStyle = gradient;
      ctx.lineWidth = 3;
      ctx.shadowColor = 'rgba(255, 0, 0, 1)';
      ctx.shadowBlur = 25;
      ctx.stroke();
      ctx.shadowBlur = 0;
    };

    const animate = () => {
      const width = canvas.offsetWidth;
      const height = canvas.offsetHeight;
      
      ctx.clearRect(0, 0, width, height);

      lines.forEach((line) => {
        drawECG(line.x, height / 2, width + 400, line.amplitude, line.phase + time * 0.025);
        line.x += line.speed;
        
        if (line.x > width) {
          line.x = -400;
          line.phase = Math.random() * Math.PI * 2;
        }
      });

      time++;
      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  const toggleSound = async () => {
    if (!audioRef.current) return;

    try {
      if (isPlaying) {
        audioRef.current.pause();
        stopBeatAnimation();
        setIsPlaying(false);
        onSoundToggle?.(false);
      } else {
        await audioRef.current.play();
        startBeatAnimation();
        setIsPlaying(true);
        onSoundToggle?.(true);
      }
    } catch (error) {
      console.error('Audio playback error:', error);
    }
  };

  // Calculate scale based on beat phase for synchronized animation
  const getHeartScale = () => {
    if (!isPlaying) return 1;
    
    // Simulate heartbeat: quick contraction then relaxation
    const normalizedPhase = beatPhase / 100;
    
    // First beat (systole) - quick contraction at 0-20%
    if (normalizedPhase < 0.2) {
      const t = normalizedPhase / 0.2;
      return 1 + Math.sin(t * Math.PI) * 0.12;
    }
    // Relaxation 20-50%
    else if (normalizedPhase < 0.5) {
      return 1;
    }
    // Second beat - smaller contraction at 50-70%
    else if (normalizedPhase < 0.7) {
      const t = (normalizedPhase - 0.5) / 0.2;
      return 1 + Math.sin(t * Math.PI) * 0.08;
    }
    // Rest period
    return 1;
  };

  const getGlowIntensity = () => {
    if (!isPlaying) return 0.4;
    
    const normalizedPhase = beatPhase / 100;
    
    if (normalizedPhase < 0.2) {
      const t = normalizedPhase / 0.2;
      return 0.4 + Math.sin(t * Math.PI) * 0.4;
    } else if (normalizedPhase < 0.5) {
      return 0.4;
    } else if (normalizedPhase < 0.7) {
      const t = (normalizedPhase - 0.5) / 0.2;
      return 0.4 + Math.sin(t * Math.PI) * 0.3;
    }
    return 0.4;
  };

  return (
    <div className="relative w-full h-[350px] sm:h-[450px] flex items-center justify-center overflow-hidden bg-background">
      {/* ECG Canvas Background */}
      <canvas 
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ background: 'transparent' }}
      />
      
      {/* Radial Glow Background */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div 
          className="w-72 h-72 sm:w-96 sm:h-96 rounded-full blur-3xl transition-opacity duration-150"
          style={{ 
            background: `rgba(255, 0, 0, ${getGlowIntensity() * 0.3})`,
          }}
        />
      </div>

      {/* Pulsing Heart SVG */}
      <div 
        className="relative z-10 cursor-pointer group"
        onClick={toggleSound}
        title={isPlaying ? "Click to mute heartbeat" : "Click to hear heartbeat"}
      >
        {/* Outer Glow Rings - sync with beat */}
        {isPlaying && (
          <>
            <div 
              className="absolute inset-0 flex items-center justify-center pointer-events-none"
              style={{ opacity: getGlowIntensity() }}
            >
              <div 
                className="w-56 h-56 sm:w-72 sm:h-72 rounded-full border-2 border-red-500/40"
                style={{ transform: `scale(${1 + (getHeartScale() - 1) * 2})` }}
              />
            </div>
            <div 
              className="absolute inset-0 flex items-center justify-center pointer-events-none"
              style={{ opacity: getGlowIntensity() * 0.7 }}
            >
              <div 
                className="w-44 h-44 sm:w-56 sm:h-56 rounded-full border border-red-500/50"
                style={{ transform: `scale(${1 + (getHeartScale() - 1) * 1.5})` }}
              />
            </div>
          </>
        )}

        {/* Heart Container - synced with beat */}
        <div 
          className="relative transition-transform duration-75"
          style={{ transform: `scale(${getHeartScale()})` }}
        >
          {/* Glow Effect */}
          <div 
            className="absolute inset-0 rounded-full blur-3xl transition-opacity duration-75"
            style={{ 
              transform: 'scale(1.8)',
              background: `radial-gradient(circle, rgba(255,0,0,${getGlowIntensity()}) 0%, rgba(255,0,0,0) 70%)`
            }}
          />
          
          {/* Anatomical Heart SVG */}
          <div className="relative p-4 sm:p-6 transition-transform duration-300 group-hover:scale-105">
            <svg 
              viewBox="0 0 100 100" 
              className="w-32 h-32 sm:w-48 sm:h-48"
              style={{ 
                filter: `drop-shadow(0 0 ${20 + getGlowIntensity() * 20}px rgba(255,0,0,0.8)) drop-shadow(0 0 ${40 + getGlowIntensity() * 30}px rgba(255,0,0,0.5))`
              }}
            >
              {/* Heart Background Glow */}
              <defs>
                <radialGradient id="heartGlow" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
                  <stop offset="0%" stopColor="#ff0000" stopOpacity="1"/>
                  <stop offset="50%" stopColor="#cc0000" stopOpacity="1"/>
                  <stop offset="100%" stopColor="#990000" stopOpacity="1"/>
                </radialGradient>
                <filter id="glow">
                  <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
                  <feMerge>
                    <feMergeNode in="coloredBlur"/>
                    <feMergeNode in="SourceGraphic"/>
                  </feMerge>
                </filter>
              </defs>
              
              {/* Anatomical Heart Shape */}
              <g filter="url(#glow)">
                {/* Main heart body */}
                <path 
                  d="M50 88 C20 65 8 45 8 32 C8 18 18 8 32 8 C40 8 47 13 50 20 C53 13 60 8 68 8 C82 8 92 18 92 32 C92 45 80 65 50 88Z"
                  fill="url(#heartGlow)"
                  stroke="#ff3333"
                  strokeWidth="1"
                />
                
                {/* Left atrium */}
                <ellipse cx="35" cy="22" rx="12" ry="10" fill="#cc0000" opacity="0.8"/>
                
                {/* Right atrium */}
                <ellipse cx="65" cy="22" rx="12" ry="10" fill="#cc0000" opacity="0.8"/>
                
                {/* Aorta */}
                <path 
                  d="M45 15 Q50 5 55 15"
                  fill="none"
                  stroke="#ff0000"
                  strokeWidth="8"
                  strokeLinecap="round"
                />
                
                {/* Pulmonary artery */}
                <path 
                  d="M38 12 Q35 2 42 5"
                  fill="none"
                  stroke="#aa0000"
                  strokeWidth="5"
                  strokeLinecap="round"
                />
                
                {/* Vena cava hint */}
                <path 
                  d="M58 10 Q62 2 65 8"
                  fill="none"
                  stroke="#880000"
                  strokeWidth="4"
                  strokeLinecap="round"
                />
                
                {/* Heart surface details */}
                <path 
                  d="M30 40 Q40 50 50 55 Q60 50 70 40"
                  fill="none"
                  stroke="#ff4444"
                  strokeWidth="0.5"
                  opacity="0.6"
                />
                <path 
                  d="M25 35 Q40 45 50 50"
                  fill="none"
                  stroke="#ff4444"
                  strokeWidth="0.5"
                  opacity="0.5"
                />
                <path 
                  d="M75 35 Q60 45 50 50"
                  fill="none"
                  stroke="#ff4444"
                  strokeWidth="0.5"
                  opacity="0.5"
                />
                
                {/* Highlight */}
                <ellipse cx="35" cy="35" rx="8" ry="12" fill="rgba(255,255,255,0.15)"/>
              </g>
            </svg>
            
            {/* Sound Indicator - sync with beat */}
            {isPlaying && (
              <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 flex gap-1">
                <div 
                  className="w-1.5 bg-red-400 rounded-full transition-all duration-75"
                  style={{ height: `${12 + getGlowIntensity() * 12}px` }}
                />
                <div 
                  className="w-1.5 bg-red-500 rounded-full transition-all duration-75"
                  style={{ height: `${16 + getGlowIntensity() * 16}px` }}
                />
                <div 
                  className="w-1.5 bg-red-400 rounded-full transition-all duration-75"
                  style={{ height: `${12 + getGlowIntensity() * 12}px` }}
                />
              </div>
            )}
          </div>
        </div>

        {/* Click Hint */}
        <p className="absolute -bottom-14 left-1/2 -translate-x-1/2 text-xs sm:text-sm text-muted-foreground whitespace-nowrap">
          {isPlaying ? '🔊 Heartbeat playing' : '🔇 Click heart to hear heartbeat'}
        </p>
      </div>
    </div>
  );
}
