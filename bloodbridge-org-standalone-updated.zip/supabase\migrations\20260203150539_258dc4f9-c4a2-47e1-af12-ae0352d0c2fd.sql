-- Add state and district columns to profiles for seeker location
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS state text DEFAULT NULL,
ADD COLUMN IF NOT EXISTS district text DEFAULT NULL,
ADD COLUMN IF NOT EXISTS taluka text DEFAULT NULL;

-- Create blood_camps table for donation camping events
CREATE TABLE IF NOT EXISTS public.blood_camps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  camp_date date NOT NULL,
  start_time time NOT NULL DEFAULT '09:00',
  end_time time NOT NULL DEFAULT '17:00',
  venue_name text NOT NULL,
  venue_address text NOT NULL,
  state text NOT NULL DEFAULT 'Maharashtra',
  district text NOT NULL,
  taluka text,
  city text NOT NULL,
  pincode text,
  latitude numeric,
  longitude numeric,
  contact_phone text NOT NULL,
  contact_email text,
  status text NOT NULL DEFAULT 'upcoming' CHECK (status IN ('upcoming', 'ongoing', 'completed', 'cancelled')),
  notifications_sent boolean NOT NULL DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on blood_camps
ALTER TABLE public.blood_camps ENABLE ROW LEVEL SECURITY;

-- Policy: Anyone can view upcoming/ongoing camps
CREATE POLICY "Anyone can view active blood camps"
ON public.blood_camps FOR SELECT
USING (status IN ('upcoming', 'ongoing'));

-- Policy: Providers can view all their own camps
CREATE POLICY "Providers can view their own camps"
ON public.blood_camps FOR SELECT
USING (EXISTS (
  SELECT 1 FROM organizations o 
  WHERE o.id = blood_camps.organization_id AND o.user_id = auth.uid()
));

-- Policy: Providers can insert camps for their approved organization
CREATE POLICY "Providers can create camps"
ON public.blood_camps FOR INSERT
WITH CHECK (EXISTS (
  SELECT 1 FROM organizations o 
  WHERE o.id = blood_camps.organization_id 
  AND o.user_id = auth.uid() 
  AND o.verification_status = 'approved'
));

-- Policy: Providers can update their own camps
CREATE POLICY "Providers can update their own camps"
ON public.blood_camps FOR UPDATE
USING (EXISTS (
  SELECT 1 FROM organizations o 
  WHERE o.id = blood_camps.organization_id AND o.user_id = auth.uid()
));

-- Policy: Providers can delete their own camps
CREATE POLICY "Providers can delete their own camps"
ON public.blood_camps FOR DELETE
USING (EXISTS (
  SELECT 1 FROM organizations o 
  WHERE o.id = blood_camps.organization_id AND o.user_id = auth.uid()
));

-- Policy: Admins can manage all camps
CREATE POLICY "Admins can manage all blood camps"
ON public.blood_camps FOR ALL
USING (has_role(auth.uid(), 'admin'));

-- Add trigger for updated_at
CREATE TRIGGER update_blood_camps_updated_at
BEFORE UPDATE ON public.blood_camps
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();