import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BLOOD_GROUPS, MAHARASHTRA_DISTRICTS, BloodGroup, SearchFilters } from '@/types';
import { Search, Heart } from 'lucide-react';

interface BloodSearchFormProps {
  onSearch: (filters: SearchFilters) => void;
  loading?: boolean;
}

export function BloodSearchForm({ onSearch, loading }: BloodSearchFormProps) {
  const [filters, setFilters] = useState<SearchFilters>({
    blood_group: null,
    state: 'Maharashtra',
    district: '',
    city: '',
    pincode: '',
  });

  const updateFilter = (key: keyof SearchFilters, value: string | null) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(filters);
  };

  return (
    <Card className="bg-card/50 backdrop-blur-xl border-primary/20 shadow-xl shadow-primary/5">
      <CardHeader className="px-4 sm:px-6 py-4 sm:py-6">
        <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
          <Heart className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
          Search Filters
        </CardTitle>
        <CardDescription className="text-xs sm:text-sm">
          Select blood group (required) and optionally choose a location. Results will be sorted by distance.
        </CardDescription>
      </CardHeader>
      <CardContent className="px-4 sm:px-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            <div className="space-y-1.5 sm:space-y-2">
              <Label htmlFor="blood_group" className="text-xs sm:text-sm">Blood Group *</Label>
              <Select
                value={filters.blood_group || ''}
                onValueChange={(v) => updateFilter('blood_group', v as BloodGroup)}
              >
                <SelectTrigger className="bg-secondary/50 border-primary/20 focus:border-primary">
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent className="bg-card/95 backdrop-blur-xl border-primary/20">
                  {BLOOD_GROUPS.map((bg) => (
                    <SelectItem key={bg} value={bg} className="hover:bg-primary/10">
                      <span className="font-medium">{bg}</span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5 sm:space-y-2">
              <Label htmlFor="district" className="text-xs sm:text-sm">District</Label>
              <Select 
                value={filters.district || '__all__'} 
                onValueChange={(v) => updateFilter('district', v === '__all__' ? '' : v)}
              >
                <SelectTrigger className="bg-secondary/50 border-primary/20 focus:border-primary">
                  <SelectValue placeholder="All" />
                </SelectTrigger>
                <SelectContent className="bg-card/95 backdrop-blur-xl border-primary/20 max-h-60">
                  <SelectItem value="__all__" className="hover:bg-primary/10">All Districts</SelectItem>
                  {MAHARASHTRA_DISTRICTS.map((district) => (
                    <SelectItem key={district} value={district} className="hover:bg-primary/10">
                      {district}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5 sm:space-y-2">
              <Label htmlFor="city" className="text-xs sm:text-sm">City</Label>
              <Input
                id="city"
                value={filters.city}
                onChange={(e) => updateFilter('city', e.target.value)}
                placeholder="Enter city"
                className="text-sm bg-secondary/50 border-primary/20 focus:border-primary"
              />
            </div>

            <div className="space-y-1.5 sm:space-y-2">
              <Label htmlFor="pincode" className="text-xs sm:text-sm">Pincode</Label>
              <Input
                id="pincode"
                value={filters.pincode}
                onChange={(e) => updateFilter('pincode', e.target.value.replace(/\D/g, '').slice(0, 6))}
                placeholder="Enter pincode"
                className="text-sm bg-secondary/50 border-primary/20 focus:border-primary"
              />
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <Button 
              type="submit" 
              disabled={!filters.blood_group || loading} 
              className="w-full sm:w-auto text-sm bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 shadow-lg shadow-primary/30 btn-neon"
            >
              <Search className="mr-2 h-4 w-4" />
              {loading ? 'Searching...' : 'Search Blood'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
