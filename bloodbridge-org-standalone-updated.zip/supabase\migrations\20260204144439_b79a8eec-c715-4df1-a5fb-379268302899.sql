-- Add INSERT policy for profiles table to fix registration
CREATE POLICY "Users can insert their own profile" 
ON public.profiles 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Create a view for public organization info (without sensitive data)
CREATE OR REPLACE VIEW public.organizations_public AS
SELECT 
  id,
  name,
  organization_type,
  city,
  district,
  state,
  pincode,
  verification_status,
  latitude,
  longitude,
  created_at
FROM public.organizations
WHERE verification_status = 'approved';

-- Grant access to the view
GRANT SELECT ON public.organizations_public TO anon, authenticated;

-- Update organizations SELECT policy to require auth for sensitive fields
DROP POLICY IF EXISTS "Organizations are viewable by everyone" ON public.organizations;

-- Allow everyone to see basic organization info
CREATE POLICY "Organizations basic info viewable by everyone" 
ON public.organizations 
FOR SELECT 
USING (
  verification_status = 'approved' OR 
  auth.uid() = user_id OR
  EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'admin')
);