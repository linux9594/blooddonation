-- Fix security definer view issue by using SECURITY INVOKER
DROP VIEW IF EXISTS public.organizations_public;

CREATE VIEW public.organizations_public 
WITH (security_invoker = true)
AS
SELECT 
  id,
  name,
  organization_type,
  city,
  district,
  state,
  pincode,
  verification_status,
  latitude,
  longitude,
  created_at
FROM public.organizations
WHERE verification_status = 'approved';

-- Grant access to the view
GRANT SELECT ON public.organizations_public TO anon, authenticated;