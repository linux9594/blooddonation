import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Organization } from '@/types';
import { Check, X, Eye, Loader2, Building2, Phone, Mail, MapPin, FileText } from 'lucide-react';
import { logAuditAction } from '@/lib/auditLog';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface PendingApprovalsProps {
  onUpdate: () => void;
  showRejected?: boolean;
}

export function PendingApprovals({ onUpdate, showRejected = false }: PendingApprovalsProps) {
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrg, setSelectedOrg] = useState<Organization | null>(null);
  const [verificationNotes, setVerificationNotes] = useState('');
  const [processing, setProcessing] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchOrganizations();
  }, [showRejected]);

  const fetchOrganizations = async () => {
    try {
      const statuses: Array<'pending' | 'rejected'> = showRejected ? ['pending', 'rejected'] : ['pending'];
      const { data, error } = await supabase
        .from('organizations')
        .select('*')
        .in('verification_status', statuses)
        .order('created_at', { ascending: true });

      if (error) throw error;
      setOrganizations(data as Organization[]);
    } catch (error) {
      console.error('Error fetching organizations:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (org: Organization) => {
    setProcessing(true);
    try {
      const { error } = await supabase
        .from('organizations')
        .update({
          verification_status: 'approved',
          verification_notes: verificationNotes || 'Approved by admin',
          verified_at: new Date().toISOString(),
        })
        .eq('id', org.id);

      if (error) throw error;

      // Initialize blood stock for the organization
      const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
      const stockInserts = bloodGroups.map(bg => ({
        organization_id: org.id,
        blood_group: bg as any,
        quantity: 0,
      }));

      await supabase.from('blood_stock').insert(stockInserts);

      // Log audit action
      await logAuditAction({
        action: 'provider_approved',
        targetType: 'organization',
        targetId: org.id,
        targetName: org.name,
        details: { organization_type: org.organization_type, city: org.city },
      });

      toast({
        title: 'Provider Approved',
        description: `${org.name} has been approved and can now manage blood stock.`,
      });

      setSelectedOrg(null);
      setVerificationNotes('');
      fetchOrganizations();
      onUpdate();
    } catch (error) {
      console.error('Error approving organization:', error);
      toast({
        title: 'Error',
        description: 'Failed to approve provider. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setProcessing(false);
    }
  };

  const handleReject = async (org: Organization) => {
    if (!verificationNotes.trim()) {
      toast({
        title: 'Notes Required',
        description: 'Please provide a reason for rejection.',
        variant: 'destructive',
      });
      return;
    }

    setProcessing(true);
    try {
      const { error } = await supabase
        .from('organizations')
        .update({
          verification_status: 'rejected',
          verification_notes: verificationNotes,
          verified_at: new Date().toISOString(),
        })
        .eq('id', org.id);

      if (error) throw error;

      // Log audit action
      await logAuditAction({
        action: 'provider_rejected',
        targetType: 'organization',
        targetId: org.id,
        targetName: org.name,
        details: { reason: verificationNotes },
      });

      toast({
        title: 'Provider Rejected',
        description: `${org.name} has been rejected.`,
      });

      setSelectedOrg(null);
      setVerificationNotes('');
      fetchOrganizations();
      onUpdate();
    } catch (error) {
      console.error('Error rejecting organization:', error);
      toast({
        title: 'Error',
        description: 'Failed to reject provider. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setProcessing(false);
    }
  };

  const getOrgTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      hospital: 'Hospital',
      blood_bank: 'Blood Bank',
      ngo: 'NGO',
      organization: 'Organization',
    };
    return labels[type] || type;
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  if (organizations.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <Check className="h-12 w-12 text-green-500 mb-4" />
          <h3 className="text-lg font-semibold">No Pending Approvals</h3>
          <p className="text-muted-foreground">All provider registrations have been processed.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>{showRejected ? 'Provider Applications' : 'Pending Provider Approvals'}</CardTitle>
          <CardDescription>
            {showRejected 
              ? 'Review pending and rejected provider applications - you can re-approve rejected providers'
              : 'Review and approve or reject provider registrations'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {organizations.map((org) => (
              <Card key={org.id} className="bg-muted/50">
                <CardContent className="pt-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="space-y-2">
                    <div className="flex items-center gap-2 flex-wrap">
                        <Building2 className="h-5 w-5 text-muted-foreground" />
                        <h4 className="font-semibold">{org.name}</h4>
                        <Badge variant="secondary">{getOrgTypeLabel(org.organization_type)}</Badge>
                        {org.verification_status === 'rejected' && (
                          <Badge variant="destructive">Rejected</Badge>
                        )}
                        {org.verification_status === 'pending' && (
                          <Badge variant="outline" className="border-yellow-500 text-yellow-600">Pending</Badge>
                        )}
                      </div>
                      <div className="flex flex-col sm:flex-row gap-2 sm:gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Phone className="h-3 w-3" /> {org.phone}
                        </span>
                        <span className="flex items-center gap-1">
                          <Mail className="h-3 w-3" /> {org.email}
                        </span>
                      </div>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <MapPin className="h-3 w-3" />
                        {org.city}, {org.district}, {org.state}
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Registered: {new Date(org.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedOrg(org)}
                      >
                        <Eye className="h-4 w-4 mr-1" /> Review
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Review Dialog */}
      <Dialog open={!!selectedOrg} onOpenChange={() => setSelectedOrg(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Review Provider Application</DialogTitle>
            <DialogDescription>
              Review the details and approve or reject this provider
            </DialogDescription>
          </DialogHeader>

          {selectedOrg && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2">Organization Details</h4>
                  <div className="space-y-1 text-sm">
                    <p><strong>Name:</strong> {selectedOrg.name}</p>
                    <p><strong>Type:</strong> {getOrgTypeLabel(selectedOrg.organization_type)}</p>
                    <p><strong>Phone:</strong> {selectedOrg.phone}</p>
                    <p><strong>Email:</strong> {selectedOrg.email}</p>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Location</h4>
                  <div className="space-y-1 text-sm">
                    <p><strong>State:</strong> {selectedOrg.state}</p>
                    <p><strong>District:</strong> {selectedOrg.district}</p>
                    <p><strong>City:</strong> {selectedOrg.city}</p>
                    {selectedOrg.taluka && <p><strong>Taluka:</strong> {selectedOrg.taluka}</p>}
                    {selectedOrg.area && <p><strong>Area:</strong> {selectedOrg.area}</p>}
                    <p><strong>Pincode:</strong> {selectedOrg.pincode}</p>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Full Address</h4>
                <p className="text-sm bg-muted p-3 rounded-md">{selectedOrg.full_address}</p>
              </div>

              {selectedOrg.aadhaar_number && (
                <div>
                  <h4 className="font-semibold mb-2">Aadhaar Number</h4>
                  <p className="text-sm">XXXX-XXXX-{selectedOrg.aadhaar_number.slice(-4)}</p>
                </div>
              )}

              {selectedOrg.document_url && (
                <div>
                  <h4 className="font-semibold mb-2">Uploaded Document</h4>
                  <Button variant="outline" size="sm" asChild>
                    <a href={selectedOrg.document_url} target="_blank" rel="noopener noreferrer">
                      <FileText className="h-4 w-4 mr-2" /> View Document
                    </a>
                  </Button>
                </div>
              )}

              <div>
                <h4 className="font-semibold mb-2">Verification Notes</h4>
                <Textarea
                  placeholder="Add notes about this application (required for rejection)"
                  value={verificationNotes}
                  onChange={(e) => setVerificationNotes(e.target.value)}
                  rows={3}
                />
              </div>
            </div>
          )}

          <DialogFooter className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setSelectedOrg(null);
                setVerificationNotes('');
              }}
              disabled={processing}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => selectedOrg && handleReject(selectedOrg)}
              disabled={processing}
            >
              {processing ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <X className="h-4 w-4 mr-2" />}
              Reject
            </Button>
            <Button
              onClick={() => selectedOrg && handleApprove(selectedOrg)}
              disabled={processing}
            >
              {processing ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Check className="h-4 w-4 mr-2" />}
              Approve
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
