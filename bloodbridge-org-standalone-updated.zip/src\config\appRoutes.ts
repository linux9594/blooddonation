// Centralized app routes.
// NOTE: Real protection is enforced by auth + role checks.

export const ADMIN_DASHBOARD_PATH = "/admin";
export const ADMIN_AUTH_PATH = "/admin/auth";
