import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Heart, Building2, User, ArrowLeft, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { AppRole, MAHARASHTRA_DISTRICTS, MAHARASHTRA_TALUKAS } from '@/types';
import { z } from 'zod';
import { ADMIN_DASHBOARD_PATH } from '@/config/appRoutes';
import { ForgotPasswordDialog } from '@/components/auth/ForgotPasswordDialog';

const emailSchema = z.string().email('Please enter a valid email address');
const passwordSchema = z.string().min(6, 'Password must be at least 6 characters');

export default function Auth() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user, role, signUp, signIn, loading: authLoading } = useAuth();
  const { toast } = useToast();

  const [activeTab, setActiveTab] = useState(searchParams.get('tab') || 'signin');
  const [selectedRole, setSelectedRole] = useState<AppRole>(
    (searchParams.get('role') as AppRole) || 'seeker'
  );
  const [loading, setLoading] = useState(false);

  // Form fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [state, setState] = useState('Maharashtra');
  const [district, setDistrict] = useState('');
  const [taluka, setTaluka] = useState('');
  const [errors, setErrors] = useState<{ email?: string; password?: string; location?: string }>({});
  const [showForgotPassword, setShowForgotPassword] = useState(false);

  // Get talukas for selected district
  const availableTalukas = district ? (MAHARASHTRA_TALUKAS[district] || []) : [];

  // Redirect if already logged in
  useEffect(() => {
    if (user && role) {
      switch (role) {
        case 'admin':
          navigate(ADMIN_DASHBOARD_PATH);
          break;
        case 'provider':
          navigate('/provider/dashboard');
          break;
        case 'seeker':
          navigate('/search');
          break;
        default:
          navigate('/');
      }
    }
  }, [user, role, navigate]);

  const validateForm = () => {
    const newErrors: { email?: string; password?: string; location?: string } = {};
    
    try {
      emailSchema.parse(email);
    } catch (e) {
      if (e instanceof z.ZodError) {
        newErrors.email = e.errors[0].message;
      }
    }

    try {
      passwordSchema.parse(password);
    } catch (e) {
      if (e instanceof z.ZodError) {
        newErrors.password = e.errors[0].message;
      }
    }

    if (activeTab === 'signup' && selectedRole === 'seeker') {
      if (!district) {
        newErrors.location = 'Please select your district';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setLoading(true);
    const { error } = await signIn(email, password);
    setLoading(false);

    if (error) {
      toast({
        title: 'Sign in failed',
        description: error.message === 'Invalid login credentials' 
          ? 'Invalid email or password. Please try again.' 
          : error.message,
        variant: 'destructive',
      });
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setLoading(true);
    const locationData = selectedRole === 'seeker' ? { state, district, taluka } : undefined;
    const { error } = await signUp(email, password, selectedRole, fullName, locationData);
    setLoading(false);

    if (error) {
      let message = error.message;
      if (error.message.includes('already registered')) {
        message = 'This email is already registered. Please sign in instead.';
      } else if (error.message.includes('rate limit') || error.message.includes('Rate limit')) {
        message = 'Too many signup attempts. Please wait a few minutes and try again.';
      } else if (error.message.includes('email')) {
        message = 'There was an issue sending the verification email. Please try again later.';
      }
      toast({
        title: 'Sign up failed',
        description: message,
        variant: 'destructive',
      });
    } else {
      toast({
        title: 'Account created!',
        description: 'Please check your email to verify your account before signing in.',
      });
      setActiveTab('signin');
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-primary/5" />
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-primary/5 rounded-full blur-3xl animate-pulse animation-delay-200" />
      </div>

      {/* Header */}
      <div className="p-3 sm:p-4 relative z-10">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors">
          <ArrowLeft className="h-4 w-4" />
          Back to Home
        </Link>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center px-3 sm:px-4 py-4 sm:py-8 relative z-10">
        <Card className="w-full max-w-md bg-card/80 backdrop-blur-xl border-primary/20 shadow-2xl shadow-primary/10">
          <CardHeader className="text-center px-4 sm:px-6">
            <Link to="/" className="flex justify-center mb-3 sm:mb-4">
              <div className="h-14 w-14 sm:h-16 sm:w-16 rounded-full bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center shadow-lg shadow-primary/30 animate-heartbeat-glow">
                <Heart className="h-7 w-7 sm:h-8 sm:w-8 text-primary-foreground fill-primary-foreground" />
              </div>
            </Link>
            <CardTitle className="text-xl sm:text-2xl">Welcome to BloodBridge</CardTitle>
            <CardDescription className="text-sm">
              {activeTab === 'signin' 
                ? 'Sign in to your account' 
                : 'Create a new account'}
            </CardDescription>
          </CardHeader>
          <CardContent className="px-4 sm:px-6">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2 mb-4 sm:mb-6 bg-secondary/50">
                <TabsTrigger value="signin" className="text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Sign In</TabsTrigger>
                <TabsTrigger value="signup" className="text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Sign Up</TabsTrigger>
              </TabsList>

              {/* Sign In Tab */}
              <TabsContent value="signin">
                <form onSubmit={handleSignIn} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="signin-email">Email</Label>
                    <Input
                      id="signin-email"
                      type="email"
                      placeholder="you@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="bg-secondary/50 border-primary/20 focus:border-primary"
                    />
                    {errors.email && (
                      <p className="text-sm text-destructive">{errors.email}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="signin-password">Password</Label>
                    <Input
                      id="signin-password"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="bg-secondary/50 border-primary/20 focus:border-primary"
                    />
                    {errors.password && (
                      <p className="text-sm text-destructive">{errors.password}</p>
                    )}
                  </div>
                  <div className="flex items-center justify-between">
                    <Button
                      type="button"
                      variant="link"
                      className="px-0 text-sm text-muted-foreground hover:text-primary"
                      onClick={() => setShowForgotPassword(true)}
                    >
                      Forgot password?
                    </Button>
                  </div>
                  <Button type="submit" className="w-full bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 shadow-lg shadow-primary/30 btn-neon" disabled={loading}>
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Signing in...
                      </>
                    ) : (
                      'Sign In'
                    )}
                  </Button>
                </form>
              </TabsContent>

              {/* Sign Up Tab */}
              <TabsContent value="signup">
                <form onSubmit={handleSignUp} className="space-y-3 sm:space-y-4">
                  {/* Role Selection */}
                  <div className="space-y-2 sm:space-y-3">
                    <Label className="text-sm">I want to register as:</Label>
                    <RadioGroup
                      value={selectedRole}
                      onValueChange={(value) => setSelectedRole(value as AppRole)}
                      className="grid grid-cols-2 gap-2 sm:gap-4"
                    >
                      <Label
                        htmlFor="role-provider"
                        className={`flex flex-col items-center gap-1 sm:gap-2 p-3 sm:p-4 rounded-lg border-2 cursor-pointer transition-all duration-300 ${
                          selectedRole === 'provider'
                            ? 'border-primary bg-primary/10 shadow-lg shadow-primary/20'
                            : 'border-primary/20 hover:border-primary/50 hover:bg-primary/5'
                        }`}
                      >
                        <RadioGroupItem
                          value="provider"
                          id="role-provider"
                          className="sr-only"
                        />
                        <Building2 className={`h-6 w-6 sm:h-8 sm:w-8 ${selectedRole === 'provider' ? 'text-primary' : 'text-muted-foreground'}`} />
                        <span className="font-medium text-sm sm:text-base">Blood Provider</span>
                        <span className="text-[10px] sm:text-xs text-muted-foreground text-center leading-tight">
                          Hospital, Blood Bank, NGO
                        </span>
                      </Label>
                      <Label
                        htmlFor="role-seeker"
                        className={`flex flex-col items-center gap-1 sm:gap-2 p-3 sm:p-4 rounded-lg border-2 cursor-pointer transition-all duration-300 ${
                          selectedRole === 'seeker'
                            ? 'border-primary bg-primary/10 shadow-lg shadow-primary/20'
                            : 'border-primary/20 hover:border-primary/50 hover:bg-primary/5'
                        }`}
                      >
                        <RadioGroupItem
                          value="seeker"
                          id="role-seeker"
                          className="sr-only"
                        />
                        <User className={`h-6 w-6 sm:h-8 sm:w-8 ${selectedRole === 'seeker' ? 'text-primary' : 'text-muted-foreground'}`} />
                        <span className="font-medium text-sm sm:text-base">Blood Seeker</span>
                        <span className="text-[10px] sm:text-xs text-muted-foreground text-center leading-tight">
                          Individual looking for blood
                        </span>
                      </Label>
                    </RadioGroup>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="signup-name">Full Name</Label>
                    <Input
                      id="signup-name"
                      type="text"
                      placeholder="John Doe"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      required
                      className="bg-secondary/50 border-primary/20 focus:border-primary"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="signup-email">Email</Label>
                    <Input
                      id="signup-email"
                      type="email"
                      placeholder="you@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="bg-secondary/50 border-primary/20 focus:border-primary"
                    />
                    {errors.email && (
                      <p className="text-sm text-destructive">{errors.email}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="signup-password">Password</Label>
                    <Input
                      id="signup-password"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="bg-secondary/50 border-primary/20 focus:border-primary"
                    />
                    {errors.password && (
                      <p className="text-sm text-destructive">{errors.password}</p>
                    )}
                  </div>

                  {/* Location fields for seekers */}
                  {selectedRole === 'seeker' && (
                    <>
                      <div className="space-y-2">
                        <Label>State</Label>
                        <Input value="Maharashtra" disabled className="bg-secondary/30 border-primary/10" />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="district">District *</Label>
                          <Select value={district} onValueChange={(v) => { setDistrict(v); setTaluka(''); }}>
                            <SelectTrigger className="bg-secondary/50 border-primary/20">
                              <SelectValue placeholder="Select district" />
                            </SelectTrigger>
                            <SelectContent className="bg-card/95 backdrop-blur-xl border-primary/20">
                              {MAHARASHTRA_DISTRICTS.map((d) => (
                                <SelectItem key={d} value={d}>{d}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="taluka">Taluka</Label>
                          <Select value={taluka} onValueChange={setTaluka} disabled={!district || availableTalukas.length === 0}>
                            <SelectTrigger className="bg-secondary/50 border-primary/20">
                              <SelectValue placeholder="Select taluka" />
                            </SelectTrigger>
                            <SelectContent className="bg-card/95 backdrop-blur-xl border-primary/20">
                              {availableTalukas.map((t) => (
                                <SelectItem key={t} value={t}>{t}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      {errors.location && (
                        <p className="text-sm text-destructive">{errors.location}</p>
                      )}
                    </>
                  )}

                  <Button type="submit" className="w-full bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 shadow-lg shadow-primary/30 btn-neon" disabled={loading}>
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Creating account...
                      </>
                    ) : (
                      <>
                        {selectedRole === 'provider' ? (
                          <>
                            <Building2 className="mr-2 h-4 w-4" />
                            Register as Provider
                          </>
                        ) : (
                          <>
                            <User className="mr-2 h-4 w-4" />
                            Register as Seeker
                          </>
                        )}
                      </>
                    )}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      <ForgotPasswordDialog 
        open={showForgotPassword} 
        onOpenChange={setShowForgotPassword} 
      />
    </div>
  );
}
