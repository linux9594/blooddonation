import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, History, CheckCircle, XCircle, Package, UserCog, Trash2 } from 'lucide-react';
import { format } from 'date-fns';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Database } from '@/integrations/supabase/types';

type AuditAction = Database['public']['Enums']['audit_action'];

interface AuditLogEntry {
  id: string;
  actor_id: string;
  action: AuditAction;
  target_type: string;
  target_id: string;
  target_name: string | null;
  details: Record<string, unknown> | null;
  created_at: string;
  actor_email?: string;
}

const ACTION_CONFIG: Record<AuditAction, { label: string; icon: React.ReactNode; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
  provider_approved: { label: 'Provider Approved', icon: <CheckCircle className="h-4 w-4" />, variant: 'default' },
  provider_rejected: { label: 'Provider Rejected', icon: <XCircle className="h-4 w-4" />, variant: 'destructive' },
  stock_updated: { label: 'Stock Updated', icon: <Package className="h-4 w-4" />, variant: 'secondary' },
  user_role_changed: { label: 'Role Changed', icon: <UserCog className="h-4 w-4" />, variant: 'outline' },
  provider_deleted: { label: 'Provider Deleted', icon: <Trash2 className="h-4 w-4" />, variant: 'destructive' },
};

export function AuditLog() {
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionFilter, setActionFilter] = useState<string>('all');

  useEffect(() => {
    fetchAuditLogs();
  }, [actionFilter]);

  const fetchAuditLogs = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('audit_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (actionFilter !== 'all') {
        query = query.eq('action', actionFilter as AuditAction);
      }

      const { data, error } = await query;

      if (error) throw error;

      // Fetch actor emails
      const actorIds = [...new Set(data?.map(log => log.actor_id) || [])];
      const { data: profiles } = await supabase
        .from('profiles')
        .select('user_id, email')
        .in('user_id', actorIds);

      const emailMap = new Map(profiles?.map(p => [p.user_id, p.email]) || []);

      const logsWithEmails: AuditLogEntry[] = data?.map(log => ({
        ...log,
        details: log.details as Record<string, unknown> | null,
        actor_email: emailMap.get(log.actor_id) || 'Unknown',
      })) || [];

      setLogs(logsWithEmails);
    } catch (error) {
      console.error('Error fetching audit logs:', error);
    } finally {
      setLoading(false);
    }
  };

  const getActionConfig = (action: AuditAction) => {
    return ACTION_CONFIG[action] || { label: action, icon: <History className="h-4 w-4" />, variant: 'outline' as const };
  };

  const formatDetails = (details: Record<string, unknown> | null) => {
    if (!details) return null;
    
    const entries = Object.entries(details);
    if (entries.length === 0) return null;

    return (
      <div className="text-xs text-muted-foreground space-y-1">
        {entries.map(([key, value]) => (
          <div key={key}>
            <span className="font-medium capitalize">{key.replace(/_/g, ' ')}:</span>{' '}
            <span>{String(value)}</span>
          </div>
        ))}
      </div>
    );
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <History className="h-5 w-5" />
              Audit Log
            </CardTitle>
            <CardDescription>
              Track all admin actions with timestamps and details
            </CardDescription>
          </div>
          <Select value={actionFilter} onValueChange={setActionFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by action" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Actions</SelectItem>
              <SelectItem value="provider_approved">Approvals</SelectItem>
              <SelectItem value="provider_rejected">Rejections</SelectItem>
              <SelectItem value="stock_updated">Stock Updates</SelectItem>
              <SelectItem value="user_role_changed">Role Changes</SelectItem>
              <SelectItem value="provider_deleted">Deletions</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : logs.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <History className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No audit logs found</p>
          </div>
        ) : (
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead>Target</TableHead>
                  <TableHead>Actor</TableHead>
                  <TableHead>Details</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logs.map((log) => {
                  const config = getActionConfig(log.action);
                  return (
                    <TableRow key={log.id}>
                      <TableCell className="whitespace-nowrap">
                        <div className="text-sm">
                          {format(new Date(log.created_at), 'MMM d, yyyy')}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {format(new Date(log.created_at), 'h:mm a')}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={config.variant} className="gap-1">
                          {config.icon}
                          {config.label}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm font-medium">
                          {log.target_name || log.target_type}
                        </div>
                        <div className="text-xs text-muted-foreground capitalize">
                          {log.target_type}
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className="text-sm">{log.actor_email}</span>
                      </TableCell>
                      <TableCell className="max-w-[200px]">
                        {formatDetails(log.details)}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
