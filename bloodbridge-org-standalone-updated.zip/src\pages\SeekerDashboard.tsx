import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Layout } from '@/components/layout/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { BLOOD_GROUPS, BloodGroup, SearchHistoryEntry, MAHARASHTRA_DISTRICTS, MAHARASHTRA_TALUKAS, BloodCamp } from '@/types';
import { User, Search, History, Droplet, Calendar, Save, Loader2, MapPin } from 'lucide-react';
import { format } from 'date-fns';

export default function SeekerDashboard() {
  const { user, profile, role, loading, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [searchHistory, setSearchHistory] = useState<SearchHistoryEntry[]>([]);
  const [upcomingCamps, setUpcomingCamps] = useState<BloodCamp[]>([]);
  const [historyLoading, setHistoryLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [profileForm, setProfileForm] = useState({
    full_name: '',
    phone: '',
    date_of_birth: '',
    blood_group: '' as BloodGroup | '',
    aadhaar_number: '',
    state: 'Maharashtra',
    district: '',
    taluka: '',
  });

  const availableTalukas = profileForm.district ? (MAHARASHTRA_TALUKAS[profileForm.district] || []) : [];

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
    if (!loading && role && role !== 'seeker') {
      navigate('/');
    }
  }, [user, role, loading, navigate]);

  useEffect(() => {
    if (profile) {
      setProfileForm({
        full_name: profile.full_name || '',
        phone: profile.phone || '',
        date_of_birth: profile.date_of_birth || '',
        blood_group: (profile.blood_group as BloodGroup) || '',
        aadhaar_number: profile.aadhaar_number || '',
        state: profile.state || 'Maharashtra',
        district: profile.district || '',
        taluka: profile.taluka || '',
      });
    }
  }, [profile]);

  useEffect(() => {
    if (user) {
      fetchSearchHistory();
      fetchUpcomingCamps();
    }
  }, [user, profile]);

  const fetchSearchHistory = async () => {
    if (!user) return;
    try {
      const { data, error } = await supabase
        .from('search_history')
        .select('*')
        .eq('user_id', user.id)
        .order('searched_at', { ascending: false })
        .limit(10);

      if (error) throw error;
      setSearchHistory(data as SearchHistoryEntry[]);
    } catch (error) {
      console.error('Error fetching search history:', error);
    } finally {
      setHistoryLoading(false);
    }
  };

  const fetchUpcomingCamps = async () => {
    if (!profile?.district) return;
    
    try {
      const today = new Date().toISOString().split('T')[0];
      const { data, error } = await supabase
        .from('blood_camps')
        .select('*')
        .eq('district', profile.district)
        .eq('status', 'upcoming')
        .gte('camp_date', today)
        .order('camp_date', { ascending: true })
        .limit(5);

      if (error) throw error;
      setUpcomingCamps(data as BloodCamp[]);
    } catch (error) {
      console.error('Error fetching camps:', error);
    }
  };

  const handleSaveProfile = async () => {
    if (!user) return;
    setSaving(true);

    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: profileForm.full_name || null,
          phone: profileForm.phone || null,
          date_of_birth: profileForm.date_of_birth || null,
          blood_group: profileForm.blood_group || null,
          aadhaar_number: profileForm.aadhaar_number || null,
          state: profileForm.state || 'Maharashtra',
          district: profileForm.district || null,
          taluka: profileForm.taluka || null,
        })
        .eq('user_id', user.id);

      if (error) throw error;

      await refreshProfile();
      toast.success('Profile updated successfully');
    } catch (error: any) {
      console.error('Error updating profile:', error);
      toast.error(error.message || 'Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Welcome, {profile?.full_name || 'User'}</h1>
          <p className="text-muted-foreground mt-1">Blood Seeker Dashboard</p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <Link to="/search">
            <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
              <CardContent className="p-6 flex items-center gap-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <Search className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Find Blood</h3>
                  <p className="text-sm text-muted-foreground">Search for blood availability near you</p>
                </div>
              </CardContent>
            </Card>
          </Link>
          
          <Card className="h-full">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="p-3 bg-accent rounded-lg">
                <Droplet className="h-8 w-8 text-accent-foreground" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Your Blood Group</h3>
                <p className="text-2xl font-bold text-primary">
                  {profile?.blood_group || 'Not set'}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Upcoming Blood Camps */}
        {upcomingCamps.length > 0 && (
          <Card className="mb-6 border-primary bg-primary/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-primary" />
                Upcoming Blood Donation Camps Near You
              </CardTitle>
              <CardDescription>
                Based on your location in {profile?.district}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {upcomingCamps.map((camp) => (
                  <div key={camp.id} className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3 bg-background rounded-lg">
                    <div>
                      <h4 className="font-medium">{camp.title}</h4>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <MapPin className="h-3 w-3" />
                        <span>{camp.venue_name}, {camp.city}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">{format(new Date(camp.camp_date), 'PPP')}</Badge>
                      <Badge variant="secondary">{camp.start_time} - {camp.end_time}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Profile Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Your Profile
              </CardTitle>
              <CardDescription>Update your personal information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="full_name">Full Name</Label>
                <Input
                  id="full_name"
                  value={profileForm.full_name}
                  onChange={(e) => setProfileForm((p) => ({ ...p, full_name: e.target.value }))}
                  placeholder="Enter your full name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <div className="flex">
                  <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-input bg-muted text-muted-foreground text-sm">
                    +91
                  </span>
                  <Input
                    id="phone"
                    value={profileForm.phone}
                    onChange={(e) =>
                      setProfileForm((p) => ({
                        ...p,
                        phone: e.target.value.replace(/\D/g, '').slice(0, 10),
                      }))
                    }
                    placeholder="9876543210"
                    className="rounded-l-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="dob">Date of Birth</Label>
                  <Input
                    id="dob"
                    type="date"
                    value={profileForm.date_of_birth}
                    onChange={(e) => setProfileForm((p) => ({ ...p, date_of_birth: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="blood_group">Blood Group</Label>
                  <Select
                    value={profileForm.blood_group}
                    onValueChange={(v) => setProfileForm((p) => ({ ...p, blood_group: v as BloodGroup }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      {BLOOD_GROUPS.map((bg) => (
                        <SelectItem key={bg} value={bg}>
                          {bg}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Location Fields */}
              <div className="space-y-2">
                <Label>Your Location (for camp notifications)</Label>
                <div className="grid grid-cols-2 gap-4">
                  <Select
                    value={profileForm.district}
                    onValueChange={(v) => setProfileForm((p) => ({ ...p, district: v, taluka: '' }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select district" />
                    </SelectTrigger>
                    <SelectContent>
                      {MAHARASHTRA_DISTRICTS.map((d) => (
                        <SelectItem key={d} value={d}>{d}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select
                    value={profileForm.taluka}
                    onValueChange={(v) => setProfileForm((p) => ({ ...p, taluka: v }))}
                    disabled={!profileForm.district || availableTalukas.length === 0}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select taluka" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableTalukas.map((t) => (
                        <SelectItem key={t} value={t}>{t}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="aadhaar">Aadhaar Number</Label>
                <Input
                  id="aadhaar"
                  value={profileForm.aadhaar_number}
                  onChange={(e) =>
                    setProfileForm((p) => ({
                      ...p,
                      aadhaar_number: e.target.value.replace(/\D/g, '').slice(0, 12),
                    }))
                  }
                  placeholder="123456789012"
                />
              </div>

              <Button onClick={handleSaveProfile} disabled={saving} className="w-full">
                {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                Save Profile
              </Button>
            </CardContent>
          </Card>

          {/* Search History Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="h-5 w-5" />
                Recent Searches
              </CardTitle>
              <CardDescription>Your blood search history</CardDescription>
            </CardHeader>
            <CardContent>
              {historyLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : searchHistory.length > 0 ? (
                <div className="space-y-3">
                  {searchHistory.map((entry) => (
                    <div
                      key={entry.id}
                      className="flex items-center justify-between p-3 bg-muted/50 rounded-lg"
                    >
                      <div className="flex items-center gap-3">
                        <Badge variant="outline" className="font-bold">
                          {entry.blood_group}
                        </Badge>
                        <div>
                          <p className="text-sm font-medium">
                            {entry.city || entry.district || 'All Maharashtra'}
                          </p>
                          <p className="text-xs text-muted-foreground flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {new Date(entry.searched_at).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <Badge variant="secondary">{entry.results_count} results</Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Search className="h-10 w-10 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">No search history yet</p>
                  <Link to="/search">
                    <Button variant="link" className="mt-2">
                      Start searching
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
