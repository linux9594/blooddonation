import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import { ADMIN_DASHBOARD_PATH, ADMIN_AUTH_PATH } from "@/config/appRoutes";
import { AIAssistant } from "@/components/ai/AIAssistant";
import Home from "./pages/Home";
import Auth from "./pages/Auth";
import AdminAuth from "./pages/AdminAuth";
import ProviderDashboard from "./pages/ProviderDashboard";
import SeekerDashboard from "./pages/SeekerDashboard";
import SearchBlood from "./pages/SearchBlood";
import ProviderDetail from "./pages/ProviderDetail";
import AdminDashboard from "./pages/AdminDashboard";
import Profile from "./pages/Profile";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/auth" element={<Auth />} />
            <Route path={ADMIN_AUTH_PATH} element={<AdminAuth />} />
            <Route path={ADMIN_DASHBOARD_PATH} element={<AdminDashboard />} />
            <Route path="/provider/dashboard" element={<ProviderDashboard />} />
            <Route path="/seeker/dashboard" element={<SeekerDashboard />} />
            <Route path="/search" element={<SearchBlood />} />
            <Route path="/provider/:id" element={<ProviderDetail />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
          {/* AI Assistant - Available on all pages */}
          <AIAssistant />
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
