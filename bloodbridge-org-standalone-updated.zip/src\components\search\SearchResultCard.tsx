import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { OrganizationWithStock, BloodGroup } from '@/types';
import { Building2, MapPin, Phone, Eye, Heart } from 'lucide-react';

interface SearchResultCardProps {
  organization: OrganizationWithStock;
  searchedBloodGroup: BloodGroup;
  distance?: number | null;
}

export function SearchResultCard({ organization, searchedBloodGroup, distance }: SearchResultCardProps) {
  const bloodStock = organization.blood_stock.find((s) => s.blood_group === searchedBloodGroup);
  const quantity = bloodStock?.quantity || 0;

  const getAvailabilityBadge = () => {
    if (quantity === 0) {
      return <Badge variant="destructive" className="border border-destructive/30">Unavailable</Badge>;
    }
    if (quantity <= 5) {
      return <Badge className="bg-warning/20 text-warning border border-warning/30">Low Stock ({quantity})</Badge>;
    }
    return <Badge className="bg-success/20 text-success border border-success/30">Available ({quantity})</Badge>;
  };

  const getOrgTypeLabel = (type: string) => {
    switch (type) {
      case 'hospital':
        return 'Hospital';
      case 'blood_bank':
        return 'Blood Bank';
      case 'ngo':
        return 'NGO';
      default:
        return 'Organization';
    }
  };

  return (
    <Card className="bg-card/50 backdrop-blur-xl border-primary/10 hover:border-primary/30 transition-all duration-300 card-hover neon-border">
      <CardContent className="p-4 sm:p-6">
        <div className="flex flex-col gap-4">
          {/* Header with org info */}
          <div className="flex items-start gap-3">
            <div className="p-2.5 bg-gradient-to-br from-primary/20 to-primary/5 rounded-xl shrink-0">
              <Building2 className="h-5 w-5 sm:h-6 sm:w-6 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-start gap-2 flex-wrap">
                <h3 className="font-semibold text-base sm:text-lg leading-tight text-foreground">{organization.name}</h3>
                <Badge variant="outline" className="text-xs shrink-0 border-primary/30 text-muted-foreground">{getOrgTypeLabel(organization.organization_type)}</Badge>
              </div>
              
              <div className="mt-2 space-y-1">
                <div className="flex items-center gap-2 text-xs sm:text-sm text-muted-foreground">
                  <MapPin className="h-3 w-3 sm:h-4 sm:w-4 shrink-0 text-primary/60" />
                  <span className="truncate">{organization.area || organization.city}, {organization.district}</span>
                </div>
                <div className="flex items-center gap-2 text-xs sm:text-sm text-muted-foreground">
                  <Phone className="h-3 w-3 sm:h-4 sm:w-4 shrink-0 text-primary/60" />
                  <span>+91 {organization.phone}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Blood availability and actions */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3 border-t border-primary/10">
            <div className="flex items-center gap-2 flex-wrap">
              <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-primary/10">
                <Heart className="h-4 w-4 text-primary fill-primary" />
                <span className="font-bold text-base sm:text-lg text-primary">{searchedBloodGroup}</span>
              </div>
              {getAvailabilityBadge()}
              {distance !== null && distance !== undefined && (
                <Badge variant="secondary" className="text-xs bg-secondary/50 border border-primary/10">
                  {distance} km away
                </Badge>
              )}
            </div>
            
            <Link to={`/provider/${organization.id}`} className="w-full sm:w-auto">
              <Button variant="outline" size="sm" className="w-full sm:w-auto text-xs sm:text-sm border-primary/30 hover:bg-primary/10 hover:border-primary hover:text-primary transition-all">
                <Eye className="mr-2 h-3 w-3 sm:h-4 sm:w-4" />
                View Details
              </Button>
            </Link>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
