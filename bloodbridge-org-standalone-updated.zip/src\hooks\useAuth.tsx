import { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { AppRole, Profile, Organization } from '@/types';

interface LocationData {
  state: string;
  district: string;
  taluka?: string;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  role: AppRole | null;
  organization: Organization | null;
  loading: boolean;
  signUp: (email: string, password: string, role: AppRole, fullName?: string, locationData?: LocationData) => Promise<{ error: Error | null }>;
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [role, setRole] = useState<AppRole | null>(null);
  const [organization, setOrganization] = useState<Organization | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchUserData = async (userId: string) => {
    try {
      // Fetch profile
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', userId)
        .single();
      
      if (profileData) {
        setProfile(profileData as Profile);
      }

      // Fetch role
      const { data: roleData } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', userId)
        .single();
      
      if (roleData) {
        setRole(roleData.role as AppRole);
      } else {
        // No role found - check if there's a pending role in user metadata
        const { data: userData } = await supabase.auth.getUser();
        const pendingRole = userData?.user?.user_metadata?.pending_role as AppRole | undefined;
        
        if (pendingRole && (pendingRole === 'provider' || pendingRole === 'seeker')) {
          // Try to insert the pending role
          const { error: insertError } = await supabase
            .from('user_roles')
            .insert({ user_id: userId, role: pendingRole });
          
          if (!insertError) {
            setRole(pendingRole);
            
            // Also update profile with location data if seeker
            if (pendingRole === 'seeker') {
              const locationState = userData?.user?.user_metadata?.location_state;
              const locationDistrict = userData?.user?.user_metadata?.location_district;
              const locationTaluka = userData?.user?.user_metadata?.location_taluka;
              
              if (locationDistrict) {
                await supabase
                  .from('profiles')
                  .update({
                    state: locationState || 'Maharashtra',
                    district: locationDistrict,
                    taluka: locationTaluka || null,
                  })
                  .eq('user_id', userId);
              }
            }
          }
        }
      }

      // Fetch organization if provider
      if (roleData?.role === 'provider') {
        const { data: orgData } = await supabase
          .from('organizations')
          .select('*')
          .eq('user_id', userId)
          .single();
        
        if (orgData) {
          setOrganization(orgData as Organization);
        }
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
    }
  };

  useEffect(() => {
    // Set up auth state listener first
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        if (session?.user) {
          // Defer Supabase calls with setTimeout
          setTimeout(() => {
            fetchUserData(session.user.id);
          }, 0);
        } else {
          setProfile(null);
          setRole(null);
          setOrganization(null);
        }
        setLoading(false);
      }
    );

    // Then check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (session?.user) {
        fetchUserData(session.user.id);
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const signUp = async (email: string, password: string, role: AppRole, fullName?: string, locationData?: LocationData) => {
    try {
      const redirectUrl = `${window.location.origin}/`;
      
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: redirectUrl,
          data: {
            full_name: fullName,
            pending_role: role, // Store role in user metadata for later use
            location_state: locationData?.state,
            location_district: locationData?.district,
            location_taluka: locationData?.taluka,
          },
        },
      });

      if (error) throw error;

      // If user is confirmed immediately (auto-confirm enabled), insert role
      if (data.user && data.session) {
        // User is immediately authenticated, insert role
        const { error: roleError } = await supabase
          .from('user_roles')
          .insert({ user_id: data.user.id, role });

        if (roleError) {
          console.error('Error inserting role:', roleError);
          // Don't throw - the user is created, role can be assigned later
        }

        // Update profile with full name and location if provided
        const profileUpdate: Record<string, any> = {};
        if (fullName) profileUpdate.full_name = fullName;
        if (locationData?.state) profileUpdate.state = locationData.state;
        if (locationData?.district) profileUpdate.district = locationData.district;
        if (locationData?.taluka) profileUpdate.taluka = locationData.taluka;
        
        if (Object.keys(profileUpdate).length > 0) {
          await supabase
            .from('profiles')
            .update(profileUpdate)
            .eq('user_id', data.user.id);
        }
      }

      return { error: null };
    } catch (error) {
      return { error: error as Error };
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;
      return { error: null };
    } catch (error) {
      return { error: error as Error };
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setSession(null);
    setProfile(null);
    setRole(null);
    setOrganization(null);
  };

  const refreshProfile = async () => {
    if (user) {
      await fetchUserData(user.id);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        profile,
        role,
        organization,
        loading,
        signUp,
        signIn,
        signOut,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
