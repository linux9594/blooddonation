-- Drop existing view if exists
DROP VIEW IF EXISTS public.organizations_public;

-- Create a secure public view for organizations that only exposes non-sensitive data
CREATE VIEW public.organizations_public
WITH (security_invoker = true)
AS SELECT 
  id,
  name,
  organization_type,
  city,
  district,
  state,
  pincode,
  latitude,
  longitude,
  verification_status,
  created_at
FROM public.organizations
WHERE verification_status = 'approved' OR is_demo_provider = true;

-- Grant select on the view
GRANT SELECT ON public.organizations_public TO anon, authenticated;

-- Add comment explaining the view
COMMENT ON VIEW public.organizations_public IS 'Public view of organizations that hides sensitive contact information (email, phone, address, aadhaar)';

-- Add explicit policy to ensure profiles can only be read by the owner
-- First check if policy exists and drop it
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'profiles' 
    AND policyname = 'Users can view own profile'
  ) THEN
    DROP POLICY "Users can view own profile" ON public.profiles;
  END IF;
END
$$;

-- Create explicit policy ensuring users can only view their own profile
CREATE POLICY "Users can view own profile"
ON public.profiles
FOR SELECT
USING (auth.uid() = user_id);