import { supabase } from '@/integrations/supabase/client';
import { Database } from '@/integrations/supabase/types';

type AuditAction = Database['public']['Enums']['audit_action'];

interface LogActionParams {
  action: AuditAction;
  targetType: string;
  targetId: string;
  targetName?: string;
  details?: Record<string, unknown>;
}

export async function logAuditAction({
  action,
  targetType,
  targetId,
  targetName,
  details,
}: LogActionParams): Promise<void> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      console.warn('Cannot log audit action: No authenticated user');
      return;
    }

    const { error } = await supabase.from('audit_logs').insert({
      actor_id: user.id,
      action,
      target_type: targetType,
      target_id: targetId,
      target_name: targetName,
      details: details as Database['public']['Tables']['audit_logs']['Insert']['details'],
    });

    if (error) {
      console.error('Error logging audit action:', error);
    }
  } catch (error) {
    console.error('Failed to log audit action:', error);
  }
}
