import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { ORGANIZATION_TYPES, MAHARASHTRA_DISTRICTS, OrganizationType } from '@/types';
import { Building2, MapPin, Phone, Mail, FileText, Upload, Loader2 } from 'lucide-react';

export function ProviderRegistrationForm() {
  const { user, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);
  const [documentFile, setDocumentFile] = useState<File | null>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    organization_type: '' as OrganizationType | '',
    phone: '',
    email: '',
    state: 'Maharashtra',
    district: '',
    city: '',
    taluka: '',
    area: '',
    pincode: '',
    full_address: '',
    aadhaar_number: '',
  });

  const updateField = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const validateStep1 = () => {
    if (!formData.name || !formData.organization_type || !formData.phone || !formData.email) {
      toast.error('Please fill all required fields');
      return false;
    }
    if (!/^\d{10}$/.test(formData.phone)) {
      toast.error('Please enter a valid 10-digit phone number');
      return false;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      toast.error('Please enter a valid email address');
      return false;
    }
    return true;
  };

  const validateStep2 = () => {
    if (!formData.district || !formData.city || !formData.pincode || !formData.full_address) {
      toast.error('Please fill all required fields');
      return false;
    }
    if (!/^\d{6}$/.test(formData.pincode)) {
      toast.error('Please enter a valid 6-digit pincode');
      return false;
    }
    return true;
  };

  const validateStep3 = () => {
    if (!formData.aadhaar_number) {
      toast.error('Please enter Aadhaar number');
      return false;
    }
    if (!/^\d{12}$/.test(formData.aadhaar_number)) {
      toast.error('Please enter a valid 12-digit Aadhaar number');
      return false;
    }
    return true;
  };

  const handleSubmit = async () => {
    if (!user) return;
    if (!validateStep3()) return;

    setLoading(true);
    try {
      let documentUrl = null;

      // Upload document if provided
      if (documentFile) {
        const fileExt = documentFile.name.split('.').pop();
        const fileName = `${user.id}/${Date.now()}.${fileExt}`;
        
        const { error: uploadError, data } = await supabase.storage
          .from('documents')
          .upload(fileName, documentFile);

        if (uploadError) throw uploadError;
        
        const { data: { publicUrl } } = supabase.storage
          .from('documents')
          .getPublicUrl(fileName);
        
        documentUrl = publicUrl;
      }

      // Create organization
      const { error } = await supabase
        .from('organizations')
        .insert({
          user_id: user.id,
          name: formData.name,
          organization_type: formData.organization_type as OrganizationType,
          phone: formData.phone,
          email: formData.email,
          state: formData.state,
          district: formData.district,
          city: formData.city,
          taluka: formData.taluka || null,
          area: formData.area || null,
          pincode: formData.pincode,
          full_address: formData.full_address,
          aadhaar_number: formData.aadhaar_number,
          document_url: documentUrl,
          verification_status: 'pending',
        });

      if (error) throw error;

      await refreshProfile();
      toast.success('Registration submitted! Your organization is pending verification.');
      navigate('/provider/dashboard');
    } catch (error: any) {
      console.error('Error submitting registration:', error);
      toast.error(error.message || 'Failed to submit registration');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Register as Blood Provider</h1>
        <p className="text-muted-foreground mt-2">Complete your organization details to get started</p>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center justify-between mb-8">
        {[1, 2, 3].map((s) => (
          <div key={s} className="flex items-center">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
              step >= s ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
            }`}>
              {s}
            </div>
            <span className={`ml-2 hidden sm:block ${step >= s ? 'text-foreground' : 'text-muted-foreground'}`}>
              {s === 1 ? 'Organization' : s === 2 ? 'Location' : 'Verification'}
            </span>
            {s < 3 && <div className={`w-12 sm:w-24 h-1 mx-4 ${step > s ? 'bg-primary' : 'bg-muted'}`} />}
          </div>
        ))}
      </div>

      {/* Step 1: Organization Details */}
      {step === 1 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Organization Details
            </CardTitle>
            <CardDescription>Tell us about your organization</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Organization Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => updateField('name', e.target.value)}
                placeholder="e.g., City Blood Bank"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="type">Organization Type *</Label>
              <Select value={formData.organization_type} onValueChange={(v) => updateField('organization_type', v)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  {ORGANIZATION_TYPES.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number *</Label>
                <div className="flex">
                  <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-input bg-muted text-muted-foreground text-sm">
                    +91
                  </span>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => updateField('phone', e.target.value.replace(/\D/g, '').slice(0, 10))}
                    placeholder="9876543210"
                    className="rounded-l-none"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => updateField('email', e.target.value)}
                  placeholder="contact@organization.com"
                />
              </div>
            </div>

            <div className="flex justify-end pt-4">
              <Button onClick={() => validateStep1() && setStep(2)}>
                Next: Location Details
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 2: Location Details */}
      {step === 2 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Location Details
            </CardTitle>
            <CardDescription>Where is your organization located?</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="state">State *</Label>
                <Input id="state" value={formData.state} disabled />
              </div>

              <div className="space-y-2">
                <Label htmlFor="district">District *</Label>
                <Select value={formData.district} onValueChange={(v) => updateField('district', v)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select district" />
                  </SelectTrigger>
                  <SelectContent>
                    {MAHARASHTRA_DISTRICTS.map((district) => (
                      <SelectItem key={district} value={district}>
                        {district}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="city">City *</Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => updateField('city', e.target.value)}
                  placeholder="e.g., Mumbai"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="taluka">Taluka</Label>
                <Input
                  id="taluka"
                  value={formData.taluka}
                  onChange={(e) => updateField('taluka', e.target.value)}
                  placeholder="e.g., Andheri"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="area">Area/Locality</Label>
                <Input
                  id="area"
                  value={formData.area}
                  onChange={(e) => updateField('area', e.target.value)}
                  placeholder="e.g., Lokhandwala"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="pincode">Pincode *</Label>
                <Input
                  id="pincode"
                  value={formData.pincode}
                  onChange={(e) => updateField('pincode', e.target.value.replace(/\D/g, '').slice(0, 6))}
                  placeholder="400001"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="full_address">Full Address *</Label>
              <Textarea
                id="full_address"
                value={formData.full_address}
                onChange={(e) => updateField('full_address', e.target.value)}
                placeholder="Complete address with landmarks"
                rows={3}
              />
            </div>

            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={() => setStep(1)}>
                Back
              </Button>
              <Button onClick={() => validateStep2() && setStep(3)}>
                Next: Verification
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 3: Verification Details */}
      {step === 3 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Verification Details
            </CardTitle>
            <CardDescription>Provide documents for verification</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="aadhaar">Aadhaar Number (Owner/Admin) *</Label>
              <Input
                id="aadhaar"
                value={formData.aadhaar_number}
                onChange={(e) => updateField('aadhaar_number', e.target.value.replace(/\D/g, '').slice(0, 12))}
                placeholder="123456789012"
              />
              <p className="text-xs text-muted-foreground">12-digit Aadhaar number of the organization owner or admin</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="document">Organization Certificate/License</Label>
              <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
                <input
                  type="file"
                  id="document"
                  accept=".pdf,.jpg,.jpeg,.png"
                  onChange={(e) => setDocumentFile(e.target.files?.[0] || null)}
                  className="hidden"
                />
                <label htmlFor="document" className="cursor-pointer">
                  <Upload className="h-10 w-10 mx-auto text-muted-foreground mb-2" />
                  {documentFile ? (
                    <p className="text-sm font-medium">{documentFile.name}</p>
                  ) : (
                    <>
                      <p className="text-sm font-medium">Click to upload</p>
                      <p className="text-xs text-muted-foreground">PDF, JPG, PNG up to 5MB</p>
                    </>
                  )}
                </label>
              </div>
            </div>

            <div className="bg-accent/50 rounded-lg p-4 mt-4">
              <h4 className="font-medium mb-2">What happens next?</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Your application will be reviewed by our admin team</li>
                <li>• Verification typically takes 1-2 business days</li>
                <li>• You'll receive an email once approved</li>
                <li>• After approval, you can start managing blood stock</li>
              </ul>
            </div>

            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={() => setStep(2)}>
                Back
              </Button>
              <Button onClick={handleSubmit} disabled={loading}>
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Submit for Verification
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
