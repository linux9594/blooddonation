export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      audit_logs: {
        Row: {
          action: Database["public"]["Enums"]["audit_action"]
          actor_id: string
          created_at: string
          details: Json | null
          id: string
          target_id: string
          target_name: string | null
          target_type: string
        }
        Insert: {
          action: Database["public"]["Enums"]["audit_action"]
          actor_id: string
          created_at?: string
          details?: Json | null
          id?: string
          target_id: string
          target_name?: string | null
          target_type: string
        }
        Update: {
          action?: Database["public"]["Enums"]["audit_action"]
          actor_id?: string
          created_at?: string
          details?: Json | null
          id?: string
          target_id?: string
          target_name?: string | null
          target_type?: string
        }
        Relationships: []
      }
      blood_camps: {
        Row: {
          camp_date: string
          city: string
          contact_email: string | null
          contact_phone: string
          created_at: string
          description: string | null
          district: string
          end_time: string
          id: string
          latitude: number | null
          longitude: number | null
          notifications_sent: boolean
          organization_id: string
          pincode: string | null
          start_time: string
          state: string
          status: string
          taluka: string | null
          title: string
          updated_at: string
          venue_address: string
          venue_name: string
        }
        Insert: {
          camp_date: string
          city: string
          contact_email?: string | null
          contact_phone: string
          created_at?: string
          description?: string | null
          district: string
          end_time?: string
          id?: string
          latitude?: number | null
          longitude?: number | null
          notifications_sent?: boolean
          organization_id: string
          pincode?: string | null
          start_time?: string
          state?: string
          status?: string
          taluka?: string | null
          title: string
          updated_at?: string
          venue_address: string
          venue_name: string
        }
        Update: {
          camp_date?: string
          city?: string
          contact_email?: string | null
          contact_phone?: string
          created_at?: string
          description?: string | null
          district?: string
          end_time?: string
          id?: string
          latitude?: number | null
          longitude?: number | null
          notifications_sent?: boolean
          organization_id?: string
          pincode?: string | null
          start_time?: string
          state?: string
          status?: string
          taluka?: string | null
          title?: string
          updated_at?: string
          venue_address?: string
          venue_name?: string
        }
        Relationships: [
          {
            foreignKeyName: "blood_camps_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "blood_camps_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_public"
            referencedColumns: ["id"]
          },
        ]
      }
      blood_stock: {
        Row: {
          blood_group: Database["public"]["Enums"]["blood_group"]
          id: string
          last_updated: string
          organization_id: string
          quantity: number
          updated_by: string | null
        }
        Insert: {
          blood_group: Database["public"]["Enums"]["blood_group"]
          id?: string
          last_updated?: string
          organization_id: string
          quantity?: number
          updated_by?: string | null
        }
        Update: {
          blood_group?: Database["public"]["Enums"]["blood_group"]
          id?: string
          last_updated?: string
          organization_id?: string
          quantity?: number
          updated_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "blood_stock_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "blood_stock_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_public"
            referencedColumns: ["id"]
          },
        ]
      }
      organizations: {
        Row: {
          aadhaar_number: string | null
          area: string | null
          city: string
          created_at: string
          district: string
          document_url: string | null
          email: string
          full_address: string
          id: string
          is_demo_provider: boolean | null
          latitude: number | null
          longitude: number | null
          name: string
          organization_type: Database["public"]["Enums"]["organization_type"]
          phone: string
          pincode: string
          state: string
          taluka: string | null
          updated_at: string
          user_id: string
          verification_notes: string | null
          verification_status: Database["public"]["Enums"]["verification_status"]
          verified_at: string | null
        }
        Insert: {
          aadhaar_number?: string | null
          area?: string | null
          city: string
          created_at?: string
          district: string
          document_url?: string | null
          email: string
          full_address: string
          id?: string
          is_demo_provider?: boolean | null
          latitude?: number | null
          longitude?: number | null
          name: string
          organization_type: Database["public"]["Enums"]["organization_type"]
          phone: string
          pincode: string
          state: string
          taluka?: string | null
          updated_at?: string
          user_id: string
          verification_notes?: string | null
          verification_status?: Database["public"]["Enums"]["verification_status"]
          verified_at?: string | null
        }
        Update: {
          aadhaar_number?: string | null
          area?: string | null
          city?: string
          created_at?: string
          district?: string
          document_url?: string | null
          email?: string
          full_address?: string
          id?: string
          is_demo_provider?: boolean | null
          latitude?: number | null
          longitude?: number | null
          name?: string
          organization_type?: Database["public"]["Enums"]["organization_type"]
          phone?: string
          pincode?: string
          state?: string
          taluka?: string | null
          updated_at?: string
          user_id?: string
          verification_notes?: string | null
          verification_status?: Database["public"]["Enums"]["verification_status"]
          verified_at?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          aadhaar_number: string | null
          avatar_url: string | null
          blood_group: Database["public"]["Enums"]["blood_group"] | null
          created_at: string
          date_of_birth: string | null
          district: string | null
          email: string | null
          full_name: string | null
          id: string
          phone: string | null
          state: string | null
          taluka: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          aadhaar_number?: string | null
          avatar_url?: string | null
          blood_group?: Database["public"]["Enums"]["blood_group"] | null
          created_at?: string
          date_of_birth?: string | null
          district?: string | null
          email?: string | null
          full_name?: string | null
          id?: string
          phone?: string | null
          state?: string | null
          taluka?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          aadhaar_number?: string | null
          avatar_url?: string | null
          blood_group?: Database["public"]["Enums"]["blood_group"] | null
          created_at?: string
          date_of_birth?: string | null
          district?: string | null
          email?: string | null
          full_name?: string | null
          id?: string
          phone?: string | null
          state?: string | null
          taluka?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      search_history: {
        Row: {
          blood_group: Database["public"]["Enums"]["blood_group"]
          city: string | null
          district: string | null
          id: string
          pincode: string | null
          results_count: number | null
          searched_at: string
          state: string | null
          user_id: string
        }
        Insert: {
          blood_group: Database["public"]["Enums"]["blood_group"]
          city?: string | null
          district?: string | null
          id?: string
          pincode?: string | null
          results_count?: number | null
          searched_at?: string
          state?: string | null
          user_id: string
        }
        Update: {
          blood_group?: Database["public"]["Enums"]["blood_group"]
          city?: string | null
          district?: string | null
          id?: string
          pincode?: string | null
          results_count?: number | null
          searched_at?: string
          state?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      verification_documents: {
        Row: {
          document_type: string
          document_url: string
          id: string
          organization_id: string
          uploaded_at: string
        }
        Insert: {
          document_type: string
          document_url: string
          id?: string
          organization_id: string
          uploaded_at?: string
        }
        Update: {
          document_type?: string
          document_url?: string
          id?: string
          organization_id?: string
          uploaded_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "verification_documents_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "verification_documents_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_public"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      organizations_public: {
        Row: {
          city: string | null
          created_at: string | null
          district: string | null
          id: string | null
          latitude: number | null
          longitude: number | null
          name: string | null
          organization_type:
            | Database["public"]["Enums"]["organization_type"]
            | null
          pincode: string | null
          state: string | null
          verification_status:
            | Database["public"]["Enums"]["verification_status"]
            | null
        }
        Insert: {
          city?: string | null
          created_at?: string | null
          district?: string | null
          id?: string | null
          latitude?: number | null
          longitude?: number | null
          name?: string | null
          organization_type?:
            | Database["public"]["Enums"]["organization_type"]
            | null
          pincode?: string | null
          state?: string | null
          verification_status?:
            | Database["public"]["Enums"]["verification_status"]
            | null
        }
        Update: {
          city?: string | null
          created_at?: string | null
          district?: string | null
          id?: string | null
          latitude?: number | null
          longitude?: number | null
          name?: string | null
          organization_type?:
            | Database["public"]["Enums"]["organization_type"]
            | null
          pincode?: string | null
          state?: string | null
          verification_status?:
            | Database["public"]["Enums"]["verification_status"]
            | null
        }
        Relationships: []
      }
    }
    Functions: {
      get_user_role: {
        Args: { _user_id: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "provider" | "seeker"
      audit_action:
        | "provider_approved"
        | "provider_rejected"
        | "stock_updated"
        | "user_role_changed"
        | "provider_deleted"
      blood_group: "A+" | "A-" | "B+" | "B-" | "AB+" | "AB-" | "O+" | "O-"
      organization_type: "hospital" | "blood_bank" | "ngo" | "organization"
      verification_status: "pending" | "approved" | "rejected"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "provider", "seeker"],
      audit_action: [
        "provider_approved",
        "provider_rejected",
        "stock_updated",
        "user_role_changed",
        "provider_deleted",
      ],
      blood_group: ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"],
      organization_type: ["hospital", "blood_bank", "ngo", "organization"],
      verification_status: ["pending", "approved", "rejected"],
    },
  },
} as const
