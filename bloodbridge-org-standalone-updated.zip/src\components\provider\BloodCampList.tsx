import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { BloodCamp } from '@/types';
import { Calendar, MapPin, Clock, Phone, Trash2, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

interface BloodCampListProps {
  organizationId: string;
  refreshTrigger: number;
}

export function BloodCampList({ organizationId, refreshTrigger }: BloodCampListProps) {
  const [camps, setCamps] = useState<BloodCamp[]>([]);
  const [loading, setLoading] = useState(true);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  useEffect(() => {
    fetchCamps();
  }, [organizationId, refreshTrigger]);

  const fetchCamps = async () => {
    try {
      const { data, error } = await supabase
        .from('blood_camps')
        .select('*')
        .eq('organization_id', organizationId)
        .order('camp_date', { ascending: true });

      if (error) throw error;
      setCamps(data as BloodCamp[]);
    } catch (error) {
      console.error('Error fetching camps:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (campId: string) => {
    if (!confirm('Are you sure you want to cancel this blood donation camp?')) return;
    
    setDeletingId(campId);
    try {
      const { error } = await supabase
        .from('blood_camps')
        .delete()
        .eq('id', campId);

      if (error) throw error;
      
      toast.success('Camp cancelled successfully');
      setCamps(camps.filter(c => c.id !== campId));
    } catch (error: any) {
      toast.error('Failed to cancel camp');
    } finally {
      setDeletingId(null);
    }
  };

  const getStatusBadge = (status: string, campDate: string) => {
    const today = new Date();
    const date = new Date(campDate);
    
    if (status === 'cancelled') {
      return <Badge variant="destructive">Cancelled</Badge>;
    }
    if (status === 'completed') {
      return <Badge variant="secondary">Completed</Badge>;
    }
    if (date < today) {
      return <Badge variant="secondary">Past</Badge>;
    }
    return <Badge className="bg-success text-success-foreground">Upcoming</Badge>;
  };

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (camps.length === 0) {
    return (
      <Card>
        <CardContent className="py-8 text-center">
          <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium">No Camps Scheduled</h3>
          <p className="text-muted-foreground mt-1">
            Schedule a blood donation camp to help save lives!
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {camps.map((camp) => (
        <Card key={camp.id}>
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 flex-wrap mb-2">
                  <h3 className="font-semibold text-lg">{camp.title}</h3>
                  {getStatusBadge(camp.status, camp.camp_date)}
                </div>
                
                {camp.description && (
                  <p className="text-sm text-muted-foreground mb-3">{camp.description}</p>
                )}
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    <span>{format(new Date(camp.camp_date), 'PPP')}</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    <span>{camp.start_time} - {camp.end_time}</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground sm:col-span-2">
                    <MapPin className="h-4 w-4 flex-shrink-0" />
                    <span>{camp.venue_name}, {camp.city}, {camp.district}</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Phone className="h-4 w-4" />
                    <span>+91 {camp.contact_phone}</span>
                  </div>
                </div>
              </div>
              
              <div className="flex sm:flex-col gap-2">
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => handleDelete(camp.id)}
                  disabled={deletingId === camp.id}
                >
                  {deletingId === camp.id ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <>
                      <Trash2 className="h-4 w-4 mr-1" />
                      Cancel
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
