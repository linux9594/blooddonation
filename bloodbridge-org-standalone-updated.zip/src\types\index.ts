// Blood groups
export type BloodGroup = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';

export const BLOOD_GROUPS: BloodGroup[] = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

// User roles
export type AppRole = 'admin' | 'provider' | 'seeker';

// Organization types
export type OrganizationType = 'hospital' | 'blood_bank' | 'ngo' | 'organization';

export const ORGANIZATION_TYPES: { value: OrganizationType; label: string }[] = [
  { value: 'hospital', label: 'Hospital' },
  { value: 'blood_bank', label: 'Blood Bank' },
  { value: 'ngo', label: 'NGO' },
  { value: 'organization', label: 'Other Organization' },
];

// Verification status
export type VerificationStatus = 'pending' | 'approved' | 'rejected';

// Profile
export interface Profile {
  id: string;
  user_id: string;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  date_of_birth: string | null;
  blood_group: BloodGroup | null;
  aadhaar_number: string | null;
  avatar_url: string | null;
  state: string | null;
  district: string | null;
  taluka: string | null;
  created_at: string;
  updated_at: string;
}

// Organization
export interface Organization {
  id: string;
  user_id: string;
  name: string;
  organization_type: OrganizationType;
  phone: string;
  email: string;
  state: string;
  district: string;
  city: string;
  taluka: string | null;
  area: string | null;
  pincode: string;
  full_address: string;
  latitude: number | null;
  longitude: number | null;
  aadhaar_number: string | null;
  document_url: string | null;
  verification_status: VerificationStatus;
  verification_notes: string | null;
  verified_at: string | null;
  is_demo_provider: boolean;
  created_at: string;
  updated_at: string;
}

// Blood Stock
export interface BloodStock {
  id: string;
  organization_id: string;
  blood_group: BloodGroup;
  quantity: number;
  last_updated: string;
  updated_by: string | null;
}

// Organization with blood stock
export interface OrganizationWithStock extends Organization {
  blood_stock: BloodStock[];
  distance?: number;
}

// Blood Camp
export interface BloodCamp {
  id: string;
  organization_id: string;
  title: string;
  description: string | null;
  camp_date: string;
  start_time: string;
  end_time: string;
  venue_name: string;
  venue_address: string;
  state: string;
  district: string;
  taluka: string | null;
  city: string;
  pincode: string | null;
  latitude: number | null;
  longitude: number | null;
  contact_phone: string;
  contact_email: string | null;
  status: 'upcoming' | 'ongoing' | 'completed' | 'cancelled';
  notifications_sent: boolean;
  created_at: string;
  updated_at: string;
}

// Blood Camp with organization
export interface BloodCampWithOrganization extends BloodCamp {
  organization: Organization;
}

// Search filters
export interface SearchFilters {
  blood_group: BloodGroup | null;
  state: string;
  district: string;
  city: string;
  pincode: string;
}

// User with role
export interface UserWithRole {
  id: string;
  email: string;
  role: AppRole;
  profile: Profile | null;
  organization?: Organization | null;
}

// Search history entry
export interface SearchHistoryEntry {
  id: string;
  user_id: string;
  blood_group: BloodGroup;
  state: string | null;
  district: string | null;
  city: string | null;
  pincode: string | null;
  results_count: number;
  searched_at: string;
}

// Maharashtra location data
export const MAHARASHTRA_DISTRICTS = [
  'Mumbai', 'Mumbai Suburban', 'Thane', 'Palghar', 'Raigad', 'Ratnagiri', 'Sindhudurg',
  'Pune', 'Satara', 'Sangli', 'Kolhapur', 'Solapur',
  'Nashik', 'Ahmednagar', 'Dhule', 'Jalgaon', 'Nandurbar',
  'Aurangabad', 'Jalna', 'Beed', 'Latur', 'Osmanabad', 'Nanded', 'Parbhani', 'Hingoli',
  'Nagpur', 'Wardha', 'Bhandara', 'Gondia', 'Chandrapur', 'Gadchiroli',
  'Amravati', 'Akola', 'Buldhana', 'Washim', 'Yavatmal'
];

export const MAHARASHTRA_TALUKAS: Record<string, string[]> = {
  'Mumbai': ['Mumbai City'],
  'Mumbai Suburban': ['Andheri', 'Borivali', 'Kurla'],
  'Thane': ['Thane', 'Kalyan', 'Ulhasnagar', 'Bhiwandi', 'Ambarnath', 'Murbad', 'Shahapur'],
  'Palghar': ['Palghar', 'Vasai', 'Dahanu', 'Talasari', 'Jawhar', 'Mokhada', 'Vada', 'Vikramgad'],
  'Pune': ['Pune City', 'Haveli', 'Mulshi', 'Mawal', 'Khed', 'Junnar', 'Ambegaon', 'Shirur', 'Daund', 'Baramati', 'Indapur', 'Purandar', 'Bhor', 'Velhe'],
  'Nagpur': ['Nagpur Urban', 'Nagpur Rural', 'Hingna', 'Kamptee', 'Ramtek', 'Parseoni', 'Katol', 'Narkhed', 'Umred', 'Kuhi', 'Saoner', 'Kalmeshwar', 'Mauda'],
  'Nashik': ['Nashik', 'Igatpuri', 'Dindori', 'Peth', 'Trimbakeshwar', 'Kalwan', 'Deola', 'Surgana', 'Baglan', 'Malegaon', 'Nandgaon', 'Chandwad', 'Niphad', 'Sinnar', 'Yeola'],
  'Aurangabad': ['Aurangabad', 'Khuldabad', 'Kannad', 'Sillod', 'Phulambri', 'Paithan', 'Gangapur', 'Vaijapur'],
  'Solapur': ['Solapur North', 'Solapur South', 'Akkalkot', 'Barshi', 'Karmala', 'Madha', 'Malshiras', 'Mangalvedhe', 'Mohol', 'Pandharpur', 'Sangola'],
  'Kolhapur': ['Karvir', 'Panhala', 'Shahuwadi', 'Kagal', 'Hatkanangle', 'Shirol', 'Radhanagari', 'Gaganbawda', 'Bhudargad', 'Ajra', 'Gadhinglaj', 'Chandgad'],
  'Satara': ['Satara', 'Jaoli', 'Koregaon', 'Wai', 'Mahabaleshwar', 'Khandala', 'Phaltan', 'Maan', 'Khatav', 'Karad', 'Patan'],
  'Raigad': ['Alibag', 'Pen', 'Panvel', 'Uran', 'Karjat', 'Khalapur', 'Mangaon', 'Roha', 'Sudhagad', 'Mahad', 'Poladpur', 'Shrivardhan', 'Mhasla', 'Tala', 'Murud'],
};

export const MUMBAI_AREAS = [
  'Andheri', 'Bandra', 'Borivali', 'Chembur', 'Colaba', 'Dadar', 'Dharavi',
  'Ghatkopar', 'Goregaon', 'Jogeshwari', 'Juhu', 'Kandivali', 'Kurla',
  'Lower Parel', 'Malad', 'Mulund', 'Powai', 'Santa Cruz', 'Versova',
  'Vikhroli', 'Worli', 'Marine Lines', 'Fort', 'Churchgate', 'CST',
  'Navi Mumbai', 'Vashi', 'Nerul', 'Panvel', 'Kharghar', 'Belapur',
  'Thane West', 'Thane East', 'Dombivli', 'Kalyan', 'Airoli', 'Ghansoli'
];
