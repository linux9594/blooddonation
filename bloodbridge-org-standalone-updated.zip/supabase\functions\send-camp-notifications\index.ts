import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.90.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-cron-secret",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const BREVO_API_KEY = Deno.env.get("BREVO_API_KEY");

async function sendBrevoEmail(to: string, subject: string, htmlContent: string): Promise<boolean> {
  if (!BREVO_API_KEY) {
    console.log("BREVO_API_KEY not set, skipping email send");
    return false;
  }

  try {
    const response = await fetch("https://api.brevo.com/v3/smtp/email", {
      method: "POST",
      headers: {
        "accept": "application/json",
        "api-key": BREVO_API_KEY,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        sender: { name: "BloodBridge", email: "noreply@bloodbridge.org" },
        to: [{ email: to }],
        subject,
        htmlContent,
      }),
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.error("Brevo API error:", errorData);
      return false;
    }

    console.log("Email sent successfully to:", to);
    return true;
  } catch (error) {
    console.error("Error sending email via Brevo:", error);
    return false;
  }
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  // Validate cron secret - this function should only be called by a scheduler
  const cronSecret = req.headers.get("x-cron-secret");
  const expectedSecret = Deno.env.get("CRON_SECRET");
  if (!expectedSecret || cronSecret !== expectedSecret) {
    // Also allow calls from authenticated admins
    const authHeader = req.headers.get("Authorization");
    if (authHeader?.startsWith("Bearer ")) {
      const supabaseAuth = createClient(SUPABASE_URL, Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
        global: { headers: { Authorization: authHeader } },
      });
      const token = authHeader.replace("Bearer ", "");
      const { data: claimsData, error: claimsError } = await supabaseAuth.auth.getClaims(token);
      if (claimsError || !claimsData?.claims) {
        return new Response(JSON.stringify({ error: "Unauthorized" }), {
          status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    } else {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
  }

  try {
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    
    const today = new Date();
    const twoDaysFromNow = new Date(today);
    twoDaysFromNow.setDate(twoDaysFromNow.getDate() + 2);
    const targetDate = twoDaysFromNow.toISOString().split('T')[0];
    
    console.log(`Checking for camps on ${targetDate}`);
    
    const { data: camps, error: campsError } = await supabase
      .from('blood_camps')
      .select(`*, organizations (name, phone, email)`)
      .eq('camp_date', targetDate)
      .eq('notifications_sent', false)
      .eq('status', 'upcoming');

    if (campsError) {
      console.error('Error fetching camps:', campsError);
      throw campsError;
    }

    if (!camps || camps.length === 0) {
      return new Response(
        JSON.stringify({ message: 'No camps to notify about', notified: 0 }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    let totalNotifications = 0;
    let emailsSent = 0;

    for (const camp of camps) {
      const { data: seekers, error: seekersError } = await supabase
        .from('profiles')
        .select('email, full_name, district, taluka')
        .eq('district', camp.district)
        .not('email', 'is', null);

      if (seekersError) {
        console.error(`Error fetching seekers for camp ${camp.id}:`, seekersError);
        continue;
      }

      const matchingSeekers = camp.taluka 
        ? seekers?.filter(s => !s.taluka || s.taluka === camp.taluka)
        : seekers;

      if (matchingSeekers && matchingSeekers.length > 0) {
        for (const seeker of matchingSeekers) {
          if (seeker.email) {
            const emailHtml = `<!DOCTYPE html><html><head><style>body{font-family:Arial,sans-serif;line-height:1.6;color:#333}.container{max-width:600px;margin:0 auto;padding:20px}.header{background:linear-gradient(135deg,#dc2626,#991b1b);color:white;padding:20px;text-align:center;border-radius:8px 8px 0 0}.content{background:#f9fafb;padding:30px;border-radius:0 0 8px 8px}.camp-details{background:white;padding:20px;border-radius:8px;margin:20px 0;border-left:4px solid #dc2626}.footer{text-align:center;color:#6b7280;font-size:12px;margin-top:20px}</style></head><body><div class="container"><div class="header"><h1>🩸 Blood Donation Camp Alert</h1></div><div class="content"><p>Dear ${seeker.full_name || 'Blood Donor'},</p><p>A blood donation camp is happening in your area in 2 days!</p><div class="camp-details"><h3>${camp.title}</h3><p><strong>📍 Venue:</strong> ${camp.venue_name}</p><p><strong>📅 Date:</strong> ${camp.camp_date}</p><p><strong>⏰ Time:</strong> ${camp.start_time} - ${camp.end_time}</p><p><strong>📍 Address:</strong> ${camp.venue_address}, ${camp.city}</p><p><strong>📞 Contact:</strong> ${camp.contact_phone}</p>${camp.description ? `<p>${camp.description}</p>` : ''}</div><p>Your donation can save up to 3 lives.</p></div><div class="footer"><p>© ${new Date().getFullYear()} BloodBridge.</p></div></div></body></html>`;

            const sent = await sendBrevoEmail(
              seeker.email,
              `🩸 Blood Donation Camp: ${camp.title} - ${camp.camp_date}`,
              emailHtml
            );

            if (sent) emailsSent++;
            totalNotifications++;
          }
        }
      }

      await supabase
        .from('blood_camps')
        .update({ notifications_sent: true })
        .eq('id', camp.id);
    }

    return new Response(
      JSON.stringify({ 
        message: `Processed ${camps.length} camps, sent ${emailsSent}/${totalNotifications} emails`,
        campsProcessed: camps.length,
        emailsSent,
        totalNotifications
      }),
      { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  } catch (error: any) {
    console.error("Error in send-camp-notifications:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  }
};

serve(handler);
