import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import type { Database } from './types';

export const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL ?? '';
export const SUPABASE_PUBLISHABLE_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ?? '';
export const isSupabaseConfigured = Boolean(SUPABASE_URL && SUPABASE_PUBLISHABLE_KEY);

const standaloneError = new Error(
  'Supabase is not configured. Add VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY to .env to enable backend features.'
);

function createMockQueryResult(data: unknown = [], error: Error | null = null) {
  const result = { data, error, count: Array.isArray(data) ? data.length : data ? 1 : 0 };

  const query = {
    select: () => query,
    insert: () => createMockQueryResult(null),
    update: () => createMockQueryResult(null),
    delete: () => createMockQueryResult(null),
    upsert: () => createMockQueryResult(null),
    eq: () => query,
    neq: () => query,
    gt: () => query,
    gte: () => query,
    lt: () => query,
    lte: () => query,
    in: () => query,
    is: () => query,
    ilike: () => query,
    order: () => query,
    limit: () => query,
    range: () => query,
    single: () => createMockQueryResult(null),
    maybeSingle: () => createMockQueryResult(null),
    then: (onFulfilled: (value: typeof result) => unknown, onRejected?: (reason: unknown) => unknown) =>
      Promise.resolve(result).then(onFulfilled, onRejected),
  };

  return query;
}

function createStandaloneSupabaseClient() {
  return {
    auth: {
      getSession: async () => ({ data: { session: null }, error: null }),
      getUser: async () => ({ data: { user: null }, error: null }),
      onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => undefined } } }),
      signInWithPassword: async () => ({ data: { user: null, session: null }, error: standaloneError }),
      signUp: async () => ({ data: { user: null, session: null }, error: standaloneError }),
      signOut: async () => ({ error: null }),
      resetPasswordForEmail: async () => ({ data: null, error: standaloneError }),
      updateUser: async () => ({ data: { user: null }, error: standaloneError }),
    },
    from: () => createMockQueryResult(),
    functions: {
      invoke: async () => ({ data: null, error: standaloneError }),
    },
    storage: {
      from: () => ({
        upload: async () => ({ data: null, error: standaloneError }),
        getPublicUrl: () => ({ data: { publicUrl: '' } }),
      }),
    },
  } as unknown as SupabaseClient<Database>;
}

export const supabase = isSupabaseConfigured
  ? createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
      auth: {
        storage: typeof window !== 'undefined' ? window.localStorage : undefined,
        persistSession: true,
        autoRefreshToken: true,
      },
    })
  : createStandaloneSupabaseClient();
