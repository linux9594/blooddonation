import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.90.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const BREVO_API_KEY = Deno.env.get("BREVO_API_KEY")!;

interface OtpRequest {
  email: string;
  action: 'send' | 'verify' | 'reset_password';
  otp?: string;
  newPassword?: string;
}

// Generate a 6-digit OTP
function generateOtp(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Send email via Brevo API
async function sendBrevoEmail(to: string, subject: string, htmlContent: string): Promise<boolean> {
  try {
    const response = await fetch("https://api.brevo.com/v3/smtp/email", {
      method: "POST",
      headers: {
        "accept": "application/json",
        "api-key": BREVO_API_KEY,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        sender: {
          name: "BloodBridge",
          email: "pcollege80@gmail.com",
        },
        to: [{ email: to }],
        subject: subject,
        htmlContent: htmlContent,
      }),
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.error("Brevo API error:", errorData);
      return false;
    }

    console.log("Email sent successfully to:", to);
    return true;
  } catch (error) {
    console.error("Error sending email via Brevo:", error);
    return false;
  }
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    const { email, action, otp, newPassword }: OtpRequest = await req.json();

    if (!email) {
      return new Response(
        JSON.stringify({ error: "Email is required" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Check if user exists
    const { data: users, error: userError } = await supabase.auth.admin.listUsers();
    const user = users?.users?.find(u => u.email === email.toLowerCase());
    
    if (!user && action !== 'verify') {
      return new Response(
        JSON.stringify({ error: "No account found with this email address" }),
        { status: 404, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    if (action === 'send') {
      // Generate OTP and store it
      const otpCode = generateOtp();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

      // Store OTP in database (we'll use a simple approach with profiles metadata)
      // For production, you might want a dedicated OTPs table
      const { error: updateError } = await supabase
        .from('profiles')
        .update({
          updated_at: new Date().toISOString(),
        })
        .eq('user_id', user!.id);

      // Store OTP temporarily (in memory for this request, we'll verify via a token approach)
      // For production, store in database. Here we'll encode it in a signed token.
      
      // Send OTP email via Brevo
      const emailSent = await sendBrevoEmail(
        email,
        "Your BloodBridge Password Reset Code",
        `
          <!DOCTYPE html>
          <html>
          <head>
            <style>
              body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
              .container { max-width: 600px; margin: 0 auto; padding: 20px; }
              .header { background: linear-gradient(135deg, #dc2626, #991b1b); color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
              .content { background: #f9fafb; padding: 30px; border-radius: 0 0 8px 8px; }
              .otp-code { font-size: 32px; font-weight: bold; letter-spacing: 8px; color: #dc2626; text-align: center; padding: 20px; background: white; border-radius: 8px; margin: 20px 0; }
              .footer { text-align: center; color: #6b7280; font-size: 12px; margin-top: 20px; }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="header">
                <h1>🩸 BloodBridge</h1>
              </div>
              <div class="content">
                <h2>Password Reset Request</h2>
                <p>You requested to reset your password. Use the code below to verify your identity:</p>
                <div class="otp-code">${otpCode}</div>
                <p><strong>This code will expire in 10 minutes.</strong></p>
                <p>If you didn't request this, please ignore this email or contact support if you have concerns.</p>
              </div>
              <div class="footer">
                <p>© ${new Date().getFullYear()} BloodBridge. Saving lives through blood donation.</p>
              </div>
            </div>
          </body>
          </html>
        `
      );

      if (!emailSent) {
        return new Response(
          JSON.stringify({ error: "Failed to send OTP email. Please try again." }),
          { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
        );
      }

      // Create a verification token that includes the OTP (encrypted/hashed in production)
      // For simplicity, we'll use Supabase's signInWithOtp which creates a proper token
      // But since we want code-only, we'll store the OTP hash
      
      // Store OTP in user metadata (temporary solution)
      const { error: metaError } = await supabase.auth.admin.updateUserById(user!.id, {
        user_metadata: {
          ...user!.user_metadata,
          reset_otp: otpCode,
          reset_otp_expires: expiresAt.toISOString(),
        },
      });

      if (metaError) {
        console.error("Error storing OTP:", metaError);
      }

      return new Response(
        JSON.stringify({ 
          success: true, 
          message: "OTP sent successfully to your email" 
        }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    if (action === 'verify') {
      if (!otp) {
        return new Response(
          JSON.stringify({ error: "OTP is required" }),
          { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
        );
      }

      // Verify OTP from user metadata
      const storedOtp = user?.user_metadata?.reset_otp;
      const expiresAt = user?.user_metadata?.reset_otp_expires;

      if (!storedOtp || !expiresAt) {
        return new Response(
          JSON.stringify({ error: "No OTP request found. Please request a new code." }),
          { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
        );
      }

      if (new Date() > new Date(expiresAt)) {
        return new Response(
          JSON.stringify({ error: "OTP has expired. Please request a new code." }),
          { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
        );
      }

      if (storedOtp !== otp) {
        return new Response(
          JSON.stringify({ error: "Invalid OTP. Please check and try again." }),
          { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
        );
      }

      // OTP verified - mark as verified
      await supabase.auth.admin.updateUserById(user!.id, {
        user_metadata: {
          ...user!.user_metadata,
          reset_otp_verified: true,
        },
      });

      return new Response(
        JSON.stringify({ 
          success: true, 
          message: "OTP verified successfully",
          userId: user!.id
        }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    if (action === 'reset_password') {
      if (!newPassword) {
        return new Response(
          JSON.stringify({ error: "New password is required" }),
          { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
        );
      }

      // Check if OTP was verified
      const otpVerified = user?.user_metadata?.reset_otp_verified;
      if (!otpVerified) {
        return new Response(
          JSON.stringify({ error: "Please verify OTP first" }),
          { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
        );
      }

      // Reset password
      const { error: resetError } = await supabase.auth.admin.updateUserById(user!.id, {
        password: newPassword,
        user_metadata: {
          ...user!.user_metadata,
          reset_otp: null,
          reset_otp_expires: null,
          reset_otp_verified: null,
        },
      });

      if (resetError) {
        return new Response(
          JSON.stringify({ error: "Failed to reset password. Please try again." }),
          { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
        );
      }

      return new Response(
        JSON.stringify({ 
          success: true, 
          message: "Password reset successfully" 
        }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    return new Response(
      JSON.stringify({ error: "Invalid action" }),
      { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );

  } catch (error: any) {
    console.error("Error in send-password-otp:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  }
};

serve(handler);
