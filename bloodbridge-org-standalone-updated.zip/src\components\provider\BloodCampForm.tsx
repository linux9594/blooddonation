import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { MAHARASHTRA_DISTRICTS, MAHARASHTRA_TALUKAS } from '@/types';
import { toast } from 'sonner';
import { Calendar, MapPin, Clock, Phone, Loader2, Plus } from 'lucide-react';

interface BloodCampFormProps {
  organizationId: string;
  onCampCreated: () => void;
}

export function BloodCampForm({ organizationId, onCampCreated }: BloodCampFormProps) {
  const [loading, setLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    camp_date: '',
    start_time: '09:00',
    end_time: '17:00',
    venue_name: '',
    venue_address: '',
    district: '',
    taluka: '',
    city: '',
    pincode: '',
    contact_phone: '',
    contact_email: '',
  });

  const availableTalukas = formData.district ? (MAHARASHTRA_TALUKAS[formData.district] || []) : [];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title || !formData.camp_date || !formData.venue_name || !formData.venue_address || !formData.district || !formData.city || !formData.contact_phone) {
      toast.error('Please fill in all required fields');
      return;
    }

    // Validate date is in future
    const campDate = new Date(formData.camp_date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (campDate < today) {
      toast.error('Camp date must be in the future');
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase
        .from('blood_camps')
        .insert({
          organization_id: organizationId,
          title: formData.title,
          description: formData.description || null,
          camp_date: formData.camp_date,
          start_time: formData.start_time,
          end_time: formData.end_time,
          venue_name: formData.venue_name,
          venue_address: formData.venue_address,
          state: 'Maharashtra',
          district: formData.district,
          taluka: formData.taluka || null,
          city: formData.city,
          pincode: formData.pincode || null,
          contact_phone: formData.contact_phone,
          contact_email: formData.contact_email || null,
          status: 'upcoming',
        });

      if (error) throw error;

      toast.success('Blood donation camp scheduled successfully! Seekers in your area will be notified 2 days before.');
      setFormData({
        title: '',
        description: '',
        camp_date: '',
        start_time: '09:00',
        end_time: '17:00',
        venue_name: '',
        venue_address: '',
        district: '',
        taluka: '',
        city: '',
        pincode: '',
        contact_phone: '',
        contact_email: '',
      });
      setShowForm(false);
      onCampCreated();
    } catch (error: any) {
      console.error('Error creating camp:', error);
      toast.error(error.message || 'Failed to schedule camp');
    } finally {
      setLoading(false);
    }
  };

  if (!showForm) {
    return (
      <Button onClick={() => setShowForm(true)} className="w-full sm:w-auto">
        <Plus className="h-4 w-4 mr-2" />
        Schedule Blood Donation Camp
      </Button>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5 text-primary" />
          Schedule Blood Donation Camp
        </CardTitle>
        <CardDescription>
          Fill in the details to schedule a blood donation camp. Blood seekers in the area will receive email notifications 2 days before the event.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="title">Camp Title *</Label>
              <Input
                id="title"
                placeholder="e.g., Blood Donation Camp - January 2026"
                value={formData.title}
                onChange={(e) => setFormData(f => ({ ...f, title: e.target.value }))}
                required
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="Additional details about the camp..."
                value={formData.description}
                onChange={(e) => setFormData(f => ({ ...f, description: e.target.value }))}
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="camp_date">Date *</Label>
              <Input
                id="camp_date"
                type="date"
                value={formData.camp_date}
                onChange={(e) => setFormData(f => ({ ...f, camp_date: e.target.value }))}
                min={new Date().toISOString().split('T')[0]}
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-2">
                <Label htmlFor="start_time">Start Time *</Label>
                <Input
                  id="start_time"
                  type="time"
                  value={formData.start_time}
                  onChange={(e) => setFormData(f => ({ ...f, start_time: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="end_time">End Time *</Label>
                <Input
                  id="end_time"
                  type="time"
                  value={formData.end_time}
                  onChange={(e) => setFormData(f => ({ ...f, end_time: e.target.value }))}
                  required
                />
              </div>
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="venue_name">Venue Name *</Label>
              <Input
                id="venue_name"
                placeholder="e.g., Community Hall, Hospital Name"
                value={formData.venue_name}
                onChange={(e) => setFormData(f => ({ ...f, venue_name: e.target.value }))}
                required
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="venue_address">Venue Address *</Label>
              <Textarea
                id="venue_address"
                placeholder="Full address of the venue"
                value={formData.venue_address}
                onChange={(e) => setFormData(f => ({ ...f, venue_address: e.target.value }))}
                rows={2}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="district">District *</Label>
              <Select
                value={formData.district}
                onValueChange={(v) => setFormData(f => ({ ...f, district: v, taluka: '' }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select district" />
                </SelectTrigger>
                <SelectContent>
                  {MAHARASHTRA_DISTRICTS.map((d) => (
                    <SelectItem key={d} value={d}>{d}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="taluka">Taluka</Label>
              <Select
                value={formData.taluka}
                onValueChange={(v) => setFormData(f => ({ ...f, taluka: v }))}
                disabled={!formData.district || availableTalukas.length === 0}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select taluka" />
                </SelectTrigger>
                <SelectContent>
                  {availableTalukas.map((t) => (
                    <SelectItem key={t} value={t}>{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="city">City *</Label>
              <Input
                id="city"
                placeholder="City name"
                value={formData.city}
                onChange={(e) => setFormData(f => ({ ...f, city: e.target.value }))}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="pincode">Pincode</Label>
              <Input
                id="pincode"
                placeholder="e.g., 400001"
                value={formData.pincode}
                onChange={(e) => setFormData(f => ({ ...f, pincode: e.target.value.replace(/\D/g, '').slice(0, 6) }))}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="contact_phone">Contact Phone *</Label>
              <Input
                id="contact_phone"
                placeholder="e.g., 9876543210"
                value={formData.contact_phone}
                onChange={(e) => setFormData(f => ({ ...f, contact_phone: e.target.value.replace(/\D/g, '').slice(0, 10) }))}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="contact_email">Contact Email</Label>
              <Input
                id="contact_email"
                type="email"
                placeholder="contact@example.com"
                value={formData.contact_email}
                onChange={(e) => setFormData(f => ({ ...f, contact_email: e.target.value }))}
              />
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="submit" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Scheduling...
                </>
              ) : (
                <>
                  <Calendar className="h-4 w-4 mr-2" />
                  Schedule Camp
                </>
              )}
            </Button>
            <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
